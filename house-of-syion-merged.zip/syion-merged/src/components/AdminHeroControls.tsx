import { useRef } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Json } from '@/integrations/supabase/types';
import { Button } from '@/components/ui/button';
import { storeOptions, useStore, type Profile } from '@/lib/store';
import { usePrefs } from '@/lib/prefs';
import { fileURL, shrink, toast } from '@/syion/shared';

/** Owner-only shortcuts on the storefront: change the banner and the transparent profile picture. */
export function AdminHeroControls() {
  const { profile } = useStore();
  const { t } = usePrefs();
  const qc = useQueryClient();
  const bannerIn = useRef<HTMLInputElement>(null);
  const avatarIn = useRef<HTMLInputElement>(null);

  const save = async (next: Profile) => {
    const { error } = await supabase.from('kv').upsert({ key: 'profile', value: next as unknown as Json, updated_at: new Date().toISOString() });
    if (error) {
      toast(t('Gagal menyimpan gambar', 'Could not save the image'));
      return;
    }
    qc.setQueryData(storeOptions.queryKey, (raw: Record<string, unknown> | undefined) => ({ ...(raw ?? {}), profile: next }));
    toast(t('Tampilan tersimpan', 'Look saved'));
  };
  const pick = (kind: 'banner' | 'avatar') => async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const src = await shrink(fileURL(file), kind === 'banner' ? 1200 : 400, 0.82, kind === 'avatar');
      await save({ ...profile, [kind]: src });
    } catch {
      toast(t('Gambar gagal dibaca', 'Could not read the image'));
    }
  };

  return (
    <div className="admin-strip">
      <Button size="sm" variant="outline" onClick={() => bannerIn.current?.click()}>
        ✎ {t('Ganti banner', 'Change banner')}
      </Button>
      <Button size="sm" variant="outline" onClick={() => avatarIn.current?.click()}>
        ✎ {t('Ganti foto profil', 'Change profile picture')}
      </Button>
      {profile.banner && (
        <Button size="sm" variant="ghost" onClick={() => void save({ ...profile, banner: null })}>
          {t('Hapus banner', 'Remove banner')}
        </Button>
      )}
      <input ref={bannerIn} type="file" accept="image/*" hidden id="banner-file" onChange={pick('banner')} />
      <input ref={avatarIn} type="file" accept="image/*" hidden id="avatar-file" onChange={pick('avatar')} />
    </div>
  );
}
