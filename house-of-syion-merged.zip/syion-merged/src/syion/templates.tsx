// @ts-nocheck
/* eslint-disable */
import { useState, useEffect, useRef, useMemo, useContext, createContext, Fragment } from "react";
import { supabase } from "@/integrations/supabase/client";
import { calculateExpiry, orderState } from "./order-state";
import { $, AppCtx, DB, DUR_OPTS, Field, ImageModal, KAO, LS, MIN_PIN, Modal, Switch, TAGS, TextModal, ToastHost, UNIT, addDays, addMonths, adminLogin, calcExpiry, cap, changePin, copyText, diffDays, durLabel, ensureFonts, fileURL, fmtDate, h, isAdminUser, isoDate, loadImg, loc, monthLabel, ok, pad, parseDur, parseISO, prodDur, rp, shrink, toast, toastBus, today, uid, unitLabel, useApp, waDigits, waUrl } from "./shared";
/* ================= promo templates ================= */
export const TPL_CATS=['cetgi-pity','kloude ei-ai','netts','kanpa','kepkat','cek gtc'];
export const TPL_SEED=[
  ['cetgi-pity','Ready stock AI','₍ᐢ•ﻌ•ᐢ₎ ✧ READY STOCK ✧\n⋆｡°✩ akun AI Plus, sharing & private\n✧ dibantu sampai bisa dipakai\n✧ slot terbatas, chat admin ya kak\n\n૮ ˶ᵔ ᵕ ᵔ˶ ა\n#zonauang #houseofsyion'],
  ['kloude ei-ai','Open order','(˶ᵔ ᵕ ᵔ˶) OPEN ORDER ♡\n✧ asisten AI buat nulis, riset & belajar\n✧ sharing / private tersedia\n✧ langsung chat admin untuk info durasi\n\n⋆｡°✩ #zonauang #appspremium'],
  ['netts','Nonton hemat','⸜(｡˃ ᵕ ˂ )⸝♡ NONTON PUAS ♡\n✧ akun streaming sharing & private\n✧ durasi 1 bulan / 1 tahun\n✧ tanya stok ke admin sebelum order\n\n#zonauang #readystock'],
  ['kanpa','Desain ready','✧･ﾟ: *✧･ﾟ:* DESAIN LANCAR ✧･ﾟ: *✧･ﾟ:*\n♡ Pro tools buat bikin konten\n♡ proses cepat, ramah pemula\n♡ chat admin untuk durasi yang tersedia\n\n#houseofsyion #promo'],
  ['kepkat','Edit video','₊˚⊹ EDIT VIDEO ₊˚⊹\n✧ fitur Pro terbuka\n✧ cocok buat konten harian\n✧ order lewat WhatsApp admin ya\n\n(๑>ᴗ<๑) #zonauang'],
  ['cek gtc','Cek stok','ฅ^•ﻌ•^ฅ CEK STOK DULU YA\n✧ stok bisa berubah kapan saja\n✧ tanya admin sebelum transfer\n\n#houseofsyion #readystock']
];
export function TemplateForm({init,onClose}){
  const A=useApp(),L=A.L;
  const [f,setF]=useState(init);const ta=useRef();
  const ins=txt=>{
    const el=ta.current,s=el?el.selectionStart:f.body.length,e=el?el.selectionEnd:f.body.length;
    const nb=f.body.slice(0,s)+txt+f.body.slice(e);setF(p=>({...p,body:nb}));
    setTimeout(()=>{if(el){el.focus();el.selectionStart=el.selectionEnd=s+txt.length}},0);
  };
  const save=async e=>{e.preventDefault();if(!f.title.trim()&&!f.body.trim()){toast(L('Isi judul atau teks dulu','Add a title or some text'));return}if(await A.saveTpl({...f,title:f.title.trim()||L('Tanpa judul','Untitled')}))onClose()};
  return h(Modal,{title:init.createdAt?L('Ubah Template','Edit Template'):L('Template Baru','New Template'),onClose,wide:true},
    $.form({className:'stack',onSubmit:save},
      $.div({className:'form-grid'},
        h(Field,{label:L('Judul','Title')},$.input({id:'t-title',type:'text',value:f.title,onChange:e=>setF({...f,title:e.target.value})})),
        h(Field,{label:L('Kategori','Category')},$.select({id:'t-cat',value:f.cat,onChange:e=>setF({...f,cat:e.target.value})},TPL_CATS.concat(['other']).map(c=>$.option({key:c,value:c},c))))),
      $.div({className:'glass pad stack',style:{gap:8}},
        $.span({className:'deco'},'✧ '+L('Sisipkan cepat','Quick insert')),
        $.div({className:'quick'},KAO.map(k=>$.button({key:k,type:'button',onClick:()=>ins(k)},k))),
        $.div({className:'quick'},TAGS.map(k=>$.button({key:k,type:'button',onClick:()=>ins(k+' ')},k)))),
      h(Field,{label:L('Teks (polos, spasi & enter dipertahankan)','Text (plain, spacing & line breaks are kept)'),full:true},$.textarea({ref:ta,id:'t-body',spellCheck:false,value:f.body,onChange:e=>setF({...f,body:e.target.value}),style:{minHeight:240}})),
      $.div({className:'row',style:{justifyContent:'flex-end'}},
        $.button({type:'button',className:'btn btn-ghost',onClick:onClose},L('Batal','Cancel')),
        $.button({type:'submit',className:'btn btn-star'},'💾 '+L('Simpan','Save')))));
}
export function Templates(){
  const A=useApp(),L=A.L;
  const [cat,setCat]=useState('all'),[q,setQ]=useState(''),[edit,setEdit]=useState(null),[manual,setManual]=useState(null),[del,setDel]=useState(null);
  const cats=['all'].concat(TPL_CATS,['other']);
  const list=A.templates.filter(t=>(cat==='all'||t.cat===cat)&&(!q.trim()||(t.title+' '+t.body).toLowerCase().includes(q.trim().toLowerCase())));
  const copy=async t=>{if(await copyText(t.body))toast(L('Tersalin! ૮ ˶ᵔ ᵕ ᵔ˶ ა','Copied! ૮ ˶ᵔ ᵕ ᵔ˶ ა'));else setManual(t.body)};
  return $.div({className:'stack'},
    $.div({className:'row'},
      $.h2({className:'sec-title'},L('Template Promo','Promo Template Bank'),$.small('✧ '+A.templates.length)),
      $.button({className:'btn btn-star sp',onClick:()=>setEdit({id:uid(),title:'',cat:cat==='all'?TPL_CATS[0]:cat,body:''})},'＋ '+L('Buat Template','Create Template'))),
    $.div({className:'chips',role:'group','aria-label':L('Kategori','Category')},cats.map(c=>$.button({key:c,className:'chip','aria-pressed':cat===c,onClick:()=>setCat(c)},c==='all'?L('Semua','All'):c))),
    $.input({id:'t-search',type:'search',placeholder:'🔍 '+L('Cari template…','Search templates…'),value:q,onChange:e=>setQ(e.target.value),style:{maxWidth:340},'aria-label':L('Cari','Search')}),
    list.length?$.div({className:'grid',style:{gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))',paddingTop:10}},list.map(t=>$.article({key:t.id,className:'glass memo'},
      $.div({className:'row',style:{flexWrap:'nowrap'}},
        $.div({style:{minWidth:0}},$.div({className:'pname',style:{fontSize:'1.1rem'}},t.title),$.span({className:'pill'},t.cat)),
        $.button({className:'btn btn-star btn-ico sp','aria-label':L('Salin teks','Copy text'),title:L('Salin','Copy'),onClick:()=>copy(t),style:{flex:'none'}},'📋')),
      $.pre({className:'pre',style:{margin:0}},t.body),
      $.div({className:'row',style:{marginTop:'auto'}},
        $.button({className:'btn btn-ghost btn-sm',onClick:()=>setEdit(t)},'✎ '+L('Ubah','Edit')),
        del===t.id?$.button({className:'btn btn-danger btn-sm',onClick:()=>{A.delTpl(t.id);setDel(null)}},L('Yakin?','Sure?')):$.button({className:'btn btn-danger btn-sm',onClick:()=>{setDel(t.id);setTimeout(()=>setDel(null),3000)}},'🗑')))))
      :$.div({className:'glass pad muted',style:{textAlign:'center'}},L('Belum ada template di sini.','No templates here yet.')),
    edit?h(TemplateForm,{init:edit,onClose:()=>setEdit(null)}):null,
    manual?h(TextModal,{text:manual,onClose:()=>setManual(null)}):null);
}


