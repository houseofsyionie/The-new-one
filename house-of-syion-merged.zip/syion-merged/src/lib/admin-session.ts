import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export type AdminSession = { ready: boolean; admin: boolean; email: string; refresh: () => Promise<void> };

async function check(): Promise<{ admin: boolean; email: string }> {
  const { data } = await supabase.auth.getSession();
  const user = data.session?.user;
  if (!user) return { admin: false, email: '' };
  // Admin access is the `admin` row in public.user_roles, never "any signed-in user".
  const { data: isAdmin, error } = await supabase.rpc('has_role', { _user_id: user.id, _role: 'admin' });
  return { admin: !error && isAdmin === true, email: user.email ?? '' };
}

export function useAdminSession(): AdminSession {
  const [state, setState] = useState({ ready: false, admin: false, email: '' });
  const refresh = useCallback(async () => {
    try {
      const r = await check();
      setState({ ready: true, ...r });
    } catch {
      setState({ ready: true, admin: false, email: '' });
    }
  }, []);
  useEffect(() => {
    void refresh();
    const { data } = supabase.auth.onAuthStateChange(() => {
      // Do not call Supabase inside this callback directly; defer to avoid auth deadlocks.
      setTimeout(() => void refresh(), 0);
    });
    return () => data.subscription.unsubscribe();
  }, [refresh]);
  return { ...state, refresh };
}
