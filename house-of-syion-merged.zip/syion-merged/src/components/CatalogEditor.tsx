import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Plus, Trash2, Save, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import type { Json } from '@/integrations/supabase/types';
import { storeOptions, useStore } from '@/lib/store';
import { usePrefs } from '@/lib/prefs';
import { catalogSchema } from '@/lib/catalog-schema';
import { defaultCatalog, guessIcon, type AppItem, type Catalog } from '@/data/catalog';

const newId = () => (typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : 'a-' + Math.random().toString(36).slice(2, 10));

export function CatalogEditor() {
  const { catalog: original, saved } = useStore();
  const { t } = usePrefs();
  const qc = useQueryClient();
  const [cat, setCat] = useState<Catalog>(() => structuredClone(original));
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);
  const [json, setJson] = useState<string | null>(null);
  const [q, setQ] = useState('');

  const edit = (fn: (c: Catalog) => void) =>
    setCat((old) => {
      const next = structuredClone(old);
      fn(next);
      return next;
    });
  const patchApp = (index: number, fn: (a: AppItem) => void) =>
    edit((c) => {
      const a = c.apps[index];
      if (a) fn(a);
    });

  const save = async () => {
    const parsed = catalogSchema.safeParse(cat);
    if (!parsed.success) {
      setStatus(t('Ada isian yang belum valid. Setiap aplikasi butuh varian, dan harga tidak boleh negatif.', 'Some fields are not valid. Every app needs a variant and prices cannot be negative.'));
      return;
    }
    setBusy(true);
    const { error } = await supabase.from('kv').upsert({ key: 'catalog', value: parsed.data as unknown as Json, updated_at: new Date().toISOString() });
    setBusy(false);
    if (error) {
      setStatus(t('Gagal menyimpan. Pastikan kamu masuk sebagai pemilik.', 'Could not save. Make sure you are signed in as the owner.'));
      return;
    }
    qc.setQueryData(storeOptions.queryKey, (raw: Record<string, unknown> | undefined) => ({ ...(raw ?? {}), catalog: parsed.data }));
    setStatus(t('Perubahan tersimpan.', 'Changes saved.'));
  };

  const applyJson = () => {
    try {
      setCat(catalogSchema.parse(JSON.parse(json ?? '')) as Catalog);
      setJson(null);
    } catch {
      setStatus(t('JSON tidak valid. Pastikan setiap produk memiliki varian dan harga tidak negatif.', 'Invalid JSON. Every product needs a variant and prices cannot be negative.'));
    }
  };

  return (
    <div className="editor">
      <h2 className="sec-title">{t('Katalog & harga', 'Catalog & prices')}</h2>
      {!saved && (
        <p className="page-note">
          {t(
            'Katalog ini menggabungkan daftar harga baru dengan produk, kolom khusus, dan catatan lama kamu. Tekan “Simpan perubahan” sekali agar tersimpan permanen. Data lama tidak dihapus.',
            'This catalog merges the new price list with your earlier products, custom fields and notes. Press “Save changes” once to keep it. Your earlier data is not deleted.',
          )}
        </p>
      )}
      <div className="editor-actions">
        <Button disabled={busy} onClick={() => void save()}>
          <Save />
          {busy ? t('Menyimpan...', 'Saving...') : t('Simpan perubahan', 'Save changes')}
        </Button>
        <Button variant="outline" onClick={() => setJson(JSON.stringify(cat, null, 2))}>
          Edit JSON
        </Button>
        <Button
          variant="outline"
          title={t('Ekspor katalog', 'Export catalog')}
          onClick={() => {
            const url = URL.createObjectURL(new Blob([JSON.stringify(cat, null, 2)], { type: 'application/json' }));
            const a = document.createElement('a');
            a.href = url;
            a.download = 'syion-catalog.json';
            a.click();
            URL.revokeObjectURL(url);
          }}
        >
          <Download />
          Export
        </Button>
        <Button
          variant="ghost"
          onClick={() => {
            if (confirmReset()) setCat(structuredClone(defaultCatalog));
          }}
        >
          Reset
        </Button>
      </div>
      <p role="status">{status}</p>

      {json !== null && (
        <div className="json-editor">
          <textarea aria-label="Katalog JSON" rows={16} value={json} onChange={(e) => setJson(e.target.value)} />
          <div className="editor-actions">
            <Button onClick={applyJson}>{t('Terapkan JSON', 'Apply JSON')}</Button>
            <Button variant="ghost" onClick={() => setJson(null)}>
              {t('Batal', 'Cancel')}
            </Button>
          </div>
        </div>
      )}

      <section>
        <h2 className="font-display">{t('Tampilan toko', 'Store look')}</h2>
        <div className="product-fields">
          <label>
            {t('Nama toko', 'Store name')}
            <input value={cat.settings?.title ?? ''} placeholder="House of Syion" onChange={(e) => edit((c) => void (c.settings = { ...c.settings, title: e.target.value || undefined }))} />
          </label>
          <label>
            {t('URL banner (https)', 'Banner URL (https)')}
            <input value={cat.settings?.bannerUrl ?? ''} placeholder={t('https://... (kosongkan untuk bawaan)', 'https://... (leave empty for the default)')} onChange={(e) => edit((c) => void (c.settings = { ...c.settings, bannerUrl: e.target.value || undefined }))} />
          </label>
          <label>
            {t('Tema bawaan', 'Default theme')}
            <select value={cat.settings?.theme ?? 'lavender'} onChange={(e) => edit((c) => void (c.settings = { ...c.settings, theme: e.target.value as 'lavender' | 'midnight' }))}>
              <option value="lavender">Pastel Cherry Blossom ({t('terang', 'light')})</option>
              <option value="midnight">Cosmic Indigo ({t('gelap', 'dark')})</option>
            </select>
          </label>
        </div>
        <p className="page-note">{t('Banner yang diunggah lewat tombol “Ganti banner” di halaman Katalog lebih diutamakan.', 'A banner uploaded with “Change banner” on the Catalog page takes priority.')}</p>
      </section>

      <section>
        <h2 className="font-display">{t('Kategori', 'Categories')}</h2>
        <div className="category-editor">
          {cat.categories.map((category, i) => (
            <div key={i}>
              <input
                aria-label={`${t('Kategori', 'Category')} ${i + 1}`}
                value={category}
                onChange={(e) =>
                  edit((c) => {
                    const old = c.categories[i];
                    c.categories[i] = e.target.value;
                    c.apps.forEach((a) => {
                      if (a.category === old) a.category = e.target.value;
                    });
                  })
                }
              />
              <Button size="icon" variant="ghost" title={t('Hapus kategori', 'Delete category')} disabled={cat.apps.some((a) => a.category === category)} onClick={() => edit((c) => void c.categories.splice(i, 1))}>
                <Trash2 />
              </Button>
            </div>
          ))}
        </div>
        <Button variant="outline" onClick={() => edit((c) => void c.categories.push(t('Kategori baru', 'New category')))}>
          <Plus />
          {t('Kategori', 'Category')}
        </Button>
      </section>

      <section>
        <div className="editor-section-heading">
          <h2 className="font-display">
            {t('Aplikasi', 'Apps')} · {cat.apps.length}
          </h2>
          <input aria-label={t('Cari produk', 'Search products')} placeholder={t('Cari nama atau kategori...', 'Search name or category...')} value={q} onChange={(e) => setQ(e.target.value)} />
          <Button
            onClick={() =>
              edit((c) => {
                c.apps.unshift({ id: newId(), name: t('Aplikasi baru', 'New app'), category: c.categories[0] ?? 'Other', icon: '📦', active: true, variants: [{ type: 'Private', duration: '1 Bulan', price: 0 }] });
              })
            }
          >
            <Plus />
            {t('Aplikasi', 'App')}
          </Button>
        </div>
        {cat.apps
          .map((a, index) => ({ a, index }))
          .filter(({ a }) => (a.name + ' ' + a.category).toLowerCase().includes(q.toLowerCase()))
          .map(({ a, index }) => (
            <details className="editor-product" key={a.id}>
              <summary>
                {a.icon || guessIcon(a.name, a.category)} {a.name}
                <span>
                  {a.active ? t('Tersedia', 'Available') : t('Tutup', 'Closed')} · {a.variants.length} {t('varian', 'variants')}
                </span>
              </summary>
              <div className="product-fields">
                <label>
                  {t('Nama', 'Name')}
                  <input value={a.name} onChange={(e) => patchApp(index, (x) => void (x.name = e.target.value))} />
                </label>
                <label>
                  {t('Kategori', 'Category')}
                  <select value={a.category} onChange={(e) => patchApp(index, (x) => void (x.category = e.target.value))}>
                    {cat.categories.map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </label>
                <label>
                  {t('Ikon/emoji', 'Icon/emoji')}
                  <input value={a.icon ?? ''} placeholder={guessIcon(a.name, a.category)} onChange={(e) => patchApp(index, (x) => void (x.icon = e.target.value || undefined))} />
                </label>
                <label>
                  {t('Catatan', 'Note')}
                  <input value={a.note ?? ''} onChange={(e) => patchApp(index, (x) => void (x.note = e.target.value))} />
                </label>
                <label className="checkbox-label">
                  <input type="checkbox" checked={a.active} onChange={(e) => patchApp(index, (x) => void (x.active = e.target.checked))} /> {t('Tersedia', 'Available')}
                </label>
              </div>

              <div className="variant-labels">
                <span>{t('Tipe akun', 'Account type')}</span>
                <span>{t('Durasi', 'Duration')}</span>
                <span>{t('Harga (Rp)', 'Price (Rp)')}</span>
              </div>
              {a.variants.map((v, i) => (
                <div className="variant-row" key={i}>
                  <input aria-label={t('Tipe akun', 'Account type')} value={v.type} onChange={(e) => patchApp(index, (x) => void (x.variants[i]!.type = e.target.value))} />
                  <input aria-label={t('Durasi', 'Duration')} value={v.duration} onChange={(e) => patchApp(index, (x) => void (x.variants[i]!.duration = e.target.value))} />
                  <input aria-label={t('Harga', 'Price')} type="number" min={0} value={v.price} onChange={(e) => patchApp(index, (x) => void (x.variants[i]!.price = Number(e.target.value)))} />
                  <Button size="icon" variant="ghost" title={t('Hapus varian', 'Delete variant')} disabled={a.variants.length === 1} onClick={() => patchApp(index, (x) => void x.variants.splice(i, 1))}>
                    <Trash2 />
                  </Button>
                </div>
              ))}
              <div className="editor-actions">
                <Button variant="outline" onClick={() => patchApp(index, (x) => void x.variants.push({ type: 'Private', duration: '1 Bulan', price: 0 }))}>
                  <Plus />
                  {t('Varian', 'Variant')}
                </Button>
              </div>

              <div className="field-editor">
                <p className="eyebrow">{t('KOLOM KHUSUS DI FORM PESANAN ADMIN', 'CUSTOM FIELDS ON THE ADMIN ORDER FORM')}</p>
                {(a.fields ?? []).map((f, i) => (
                  <div className="field-row" key={f.id}>
                    <input aria-label={t('Nama kolom', 'Field name')} value={f.label} onChange={(e) => patchApp(index, (x) => void (x.fields![i]!.label = e.target.value))} />
                    <select aria-label={t('Jenis', 'Type')} value={f.type} onChange={(e) => patchApp(index, (x) => void (x.fields![i]!.type = e.target.value as typeof f.type))}>
                      {(['text', 'number', 'date', 'textarea'] as const).map((ty) => (
                        <option key={ty}>{ty}</option>
                      ))}
                    </select>
                    <label className="checkbox-label">
                      <input type="checkbox" checked={f.required} onChange={(e) => patchApp(index, (x) => void (x.fields![i]!.required = e.target.checked))} /> {t('Wajib', 'Required')}
                    </label>
                    <Button size="icon" variant="ghost" title={t('Hapus kolom', 'Delete field')} onClick={() => patchApp(index, (x) => void x.fields!.splice(i, 1))}>
                      <Trash2 />
                    </Button>
                  </div>
                ))}
                <Button variant="outline" size="sm" onClick={() => patchApp(index, (x) => void (x.fields = [...(x.fields ?? []), { id: newId(), label: '', type: 'text', required: false }]))}>
                  <Plus />
                  {t('Tambah kolom', 'Add field')}
                </Button>
              </div>

              <div className="editor-actions">
                <DeleteApp name={a.name} onDelete={() => edit((c) => void c.apps.splice(index, 1))} />
              </div>
            </details>
          ))}
      </section>
    </div>
  );
}

/* Two-step delete, so nothing relies on browser dialogs. */
function DeleteApp({ name, onDelete }: { name: string; onDelete: () => void }) {
  const { t } = usePrefs();
  const [sure, setSure] = useState(false);
  return sure ? (
    <Button variant="destructive" onClick={onDelete}>
      <Trash2 />
      {t('Yakin hapus', 'Confirm delete')} {name}?
    </Button>
  ) : (
    <Button variant="destructive" onClick={() => setSure(true)}>
      <Trash2 />
      {t('Hapus aplikasi', 'Delete app')}
    </Button>
  );
}

const confirmReset = () => typeof window === 'undefined' || window.confirm('Reset katalog ke daftar harga bawaan? Perlu “Simpan perubahan” untuk menerapkan.');
