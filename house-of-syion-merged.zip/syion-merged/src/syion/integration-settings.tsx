// @ts-nocheck
/* eslint-disable */
import { useState, useEffect, useRef, useMemo, useContext, createContext, Fragment } from "react";
import { supabase } from "@/integrations/supabase/client";
import { calculateExpiry, orderState } from "./order-state";
import { $, AppCtx, DB, DUR_OPTS, Field, ImageModal, KAO, LS, MIN_PIN, Modal, Switch, TAGS, TextModal, ToastHost, UNIT, addDays, addMonths, adminLogin, calcExpiry, cap, changePin, copyText, diffDays, durLabel, ensureFonts, fileURL, fmtDate, h, isAdminUser, isoDate, loadImg, loc, monthLabel, ok, pad, parseDur, parseISO, prodDur, rp, shrink, toast, toastBus, today, uid, unitLabel, useApp, waDigits, waUrl } from "./shared";
export function IntegrationSettings(){
  const A=useApp(),L=A.L;
  const [hook,setHook]=useState(A.adminKV.sheets_webhook||'');
  const r=A.adminKV.reminder||{};
  const [to,setTo]=useState(r.to||''),[from,setFrom]=useState(r.from||'');
  const save=async e=>{
    e.preventDefault();
    const a=await A.saveAdminKV('sheets_webhook',hook.trim());
    const b=await A.saveAdminKV('reminder',{to:to.trim(),from:from.trim()});
    if(a&&b)toast(L('Tersimpan','Saved'));
  };
  return $.form({className:'glass pad stack',onSubmit:save},
    $.h3(L('Pengingat & Ekspor','Reminders & Export')),
    $.p({className:'muted'},L('Setiap hari jam 09:00 WIB, pesanan > 1 bulan yang berakhir 3 hari lagi dikirim ke email ini.','Every day at 09:00 WIB, orders longer than 1 month that end in 3 days are emailed here.')),
    $.div({className:'form-grid'},
      h(Field,{label:L('Email penerima pengingat','Reminder recipient email')},$.input({id:'r-to',type:'email',value:to,onChange:e=>setTo(e.target.value)})),
      h(Field,{label:L('Pengirim (From)','Sender (From)')},$.input({id:'r-from',type:'text',placeholder:'House of Syion <onboarding@resend.dev>',value:from,onChange:e=>setFrom(e.target.value)})),
      h(Field,{label:L('URL Google Apps Script (opsional)','Google Apps Script URL (optional)'),full:true},$.input({id:'s-hook',type:'text',placeholder:'https://script.google.com/macros/s/…/exec',value:hook,onChange:e=>setHook(e.target.value)}))),
    $.div({className:'row'},$.button({className:'btn btn-star',type:'submit'},'💾 '+L('Simpan','Save'))));
}
