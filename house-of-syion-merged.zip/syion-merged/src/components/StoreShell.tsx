import { Link, useRouterState } from '@tanstack/react-router';
import { useState, type ReactNode } from 'react';
import { Diamond, Grid2X2, UserRound, MessageCircle, Mail, Menu, Moon, Sun, PanelLeftClose, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useStore, waDisplay, waLink, DEFAULT_X, DEFAULT_NICK } from '@/lib/store';
import { usePrefs, useApplyTheme } from '@/lib/prefs';
import { useAdminSession } from '@/lib/admin-session';
import { ToastHost } from '@/syion/shared';

export function StoreShell({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobile, setMobile] = useState(false);
  const { catalog, profile } = useStore();
  const { t, lang, setLang, setTheme } = usePrefs();
  const theme = useApplyTheme(catalog.settings?.theme);
  const session = useAdminSession();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const x = (profile.x || DEFAULT_X).replace(/^@/, '');

  const links = [
    { to: '/', label: t('Katalog', 'Catalog'), icon: Grid2X2 },
    { to: '/profile', label: t('Profil / Info X', 'Profile / X Info'), icon: UserRound },
    { to: '/testimonials', label: t('Testimoni', 'Testimonials'), icon: MessageCircle },
    { to: '/contact', label: t('Kontak', 'Contact'), icon: Mail },
  ] as const;

  return (
    <div className={`store-layout ${collapsed ? 'is-collapsed' : ''}`}>
      <aside className={`store-sidebar ${mobile ? 'mobile-open' : ''}`}>
        <Link to="/" className="brand">
          <Diamond />
          <span>
            House of
            <br />
            Syion ✧
          </span>
        </Link>
        <p className="eyebrow sidebar-label">THE STARLIGHT COLLECTION</p>
        <nav>
          {links.map((l) => (
            <Button key={l.to} asChild variant="ghost" className={`nav-item ${path === l.to ? 'selected' : ''}`} title={l.label}>
              <Link to={l.to} onClick={() => setMobile(false)}>
                <l.icon />
                <span>{l.label}</span>
              </Link>
            </Button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <Moon size={18} />
          <p className="font-display">
            A little magic,
            <br />
            for your everyday.
          </p>
          <small>with love & calm ✧</small>
        </div>
      </aside>
      {mobile && <div className="mobile-overlay" onClick={() => setMobile(false)} />}
      <div className="store-main">
        <header className="topbar">
          <Button
            variant="ghost"
            size="icon"
            title={t('Buka atau tutup menu', 'Open or close the menu')}
            aria-label={t('Buka atau tutup menu', 'Open or close the menu')}
            onClick={() => {
              setCollapsed(!collapsed);
              setMobile(!mobile);
            }}
          >
            {collapsed ? <Menu /> : <PanelLeftClose />}
          </Button>
          <span className="topbar-caption">{t('Semesta kecil aplikasi premium kamu', 'Your little universe of premium apps')}</span>
          <div className="topbar-actions">
            <span className="customer-mode">{session.admin ? 'Owner' : t('Pelanggan', 'Customer')}</span>
            <div className="lang-switch" role="group" aria-label="Language">
              {(['id', 'en'] as const).map((l) => (
                <button key={l} type="button" aria-pressed={lang === l} onClick={() => setLang(l)}>
                  {l.toUpperCase()}
                </button>
              ))}
            </div>
            <Button asChild size="sm" variant="ghost">
              <Link to="/admin">
                <Shield />
                Admin
              </Link>
            </Button>
            <Button size="icon" variant="ghost" title={t('Ganti tema', 'Switch theme')} aria-label={t('Ganti tema', 'Switch theme')} onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
              {theme === 'dark' ? <Sun /> : <Moon />}
            </Button>
          </div>
        </header>
        <div className="store-body">
          <main>{children}</main>
          <aside className="right-rail">
            <section className="profile-card">
              {profile.avatar ? <img className="avatar avatar-img" src={profile.avatar} alt="" /> : <div className="avatar">✧</div>}
              <h2 className="font-display">{profile.nick || DEFAULT_NICK}</h2>
              <a href={`https://x.com/${x}`} target="_blank" rel="noreferrer">
                @{x} ↗
              </a>
              <hr />
              <p>with love & calm</p>
            </section>
            <section className="rail-item">
              <h2 className="font-display">✧ Little notices</h2>
              <p>✦ {t('Pesan langsung via WhatsApp.', 'Order directly via WhatsApp.')}</p>
              <p>✦ {t('Pembayaran melalui QRIS.', 'Payment via QRIS.')}</p>
              <p>✦ {t('Closed: sementara tidak tersedia.', 'Closed: temporarily unavailable.')}</p>
            </section>
            <section className="rail-item">
              <h2 className="font-display">Explore categories</h2>
              {catalog.categories.map((c) => (
                <Link key={c} to="/">
                  {c} ↗
                </Link>
              ))}
            </section>
            <section className="rail-item">
              <h2 className="font-display">
                House of Syion
                <br />
                by Syionie
              </h2>
              <small>© 2026 House of Syion by Syionie.</small>
              <a href={waLink(profile)} target="_blank" rel="noreferrer">
                {waDisplay(profile)}
              </a>
            </section>
          </aside>
        </div>
        <footer className="store-footer">© 2026 House of Syion · with love & calm ✧</footer>
      </div>
      <ToastHost />
    </div>
  );
}
