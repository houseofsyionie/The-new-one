// @ts-nocheck
/* eslint-disable */
import { useCallback, useEffect, useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { CatalogEditor } from "@/components/CatalogEditor";
import { Button } from "@/components/ui/button";
import { storeOptions, toolProducts, useStore } from "@/lib/store";
import { usePrefs } from "@/lib/prefs";
import { useAdminSession } from "@/lib/admin-session";
import { AppCtx, DB, adminLogin, changePin as changeAuthPin, toast, uid } from "./shared";
import { PinGate } from "./pin-gate";
import { Orders } from "./orders";
import { Studio } from "./studio";
import { Templates, TPL_SEED } from "./templates";
import { Settings } from "./settings";
import { TestimonialsAdmin } from "./testimonials-admin";

const TABS = [
  ["orders", "🧾", "Pesanan", "Orders"],
  ["catalog", "🏷", "Katalog & harga", "Catalog & prices"],
  ["studio", "🖼", "Watermark Studio", "Watermark Studio"],
  ["templates", "📝", "Template Promo", "Promo Templates"],
  ["testimonials", "💬", "Testimoni", "Testimonials"],
  ["settings", "⚙️", "Pengaturan", "Settings"],
];
const readTab = () => {
  const h = typeof location === "undefined" ? "" : location.hash.slice(1);
  return TABS.some((t) => t[0] === h) ? h : "orders";
};

export default function AdminApp() {
  const session = useAdminSession();
  if (!session.ready) return <p className="empty-state">…</p>;
  return session.admin ? <Workspace session={session} /> : <Gate session={session} />;
}

function Gate({ session }) {
  const { lang } = usePrefs();
  const A = {
    lang,
    L: (a, b) => (lang === "id" ? a : b),
    login: async (email, pin) => {
      const r = await adminLogin(email, pin);
      if (r === "ok") await session.refresh();
      return r;
    },
  };
  return <AppCtx.Provider value={A}><PinGate /></AppCtx.Provider>;
}

function Workspace({ session }) {
  const store = useStore();
  const qc = useQueryClient();
  const { lang, setLang } = usePrefs();
  const L = (a, b) => (lang === "id" ? a : b);
  const [tab, setTab] = useState(readTab);
  const [orders, setOrders] = useState([]), [templates, setTemplates] = useState([]), [adminKV, setAdminKV] = useState({});

  useEffect(() => {
    const f = () => { setTab(readTab()); scrollTo(0, 0); };
    addEventListener("hashchange", f);
    return () => removeEventListener("hashchange", f);
  }, []);
  const go = (t) => { location.hash = t; };

  const loadAdmin = useCallback(async () => {
    try { setOrders(await DB.list("orders")); } catch (e) {}
    try { setAdminKV(await DB.getAdminKV()); } catch (e) {}
    try {
      let tp = await DB.list("templates");
      if (!tp.length) {
        const kv = await DB.getKV();
        if (!kv.tpl_seeded) {
          const seeded = TPL_SEED.map((s) => ({ id: uid(), cat: s[0], title: s[1], body: s[2], createdAt: Date.now() }));
          for (const t of seeded) await DB.put("templates", t);
          await DB.setKV("tpl_seeded", true);
          tp = seeded;
        }
      }
      setTemplates(tp);
    } catch (e) {}
  }, []);
  useEffect(() => {
    loadAdmin();
    const t = setInterval(loadAdmin, 15000);
    return () => clearInterval(t);
  }, [loadAdmin]);

  const patchRaw = (k, v) => qc.setQueryData(storeOptions.queryKey, (raw) => ({ ...(raw || {}), [k]: v }));
  const saveKV = async (k, v) => {
    try { await DB.setKV(k, v); patchRaw(k, v); return true; }
    catch (e) { toast(L("Gagal menyimpan (penyimpanan penuh atau koneksi)", "Could not save (storage full or connection)")); return false; }
  };
  const setProfile = (p) => saveKV("profile", p);
  const addTesti = async (src) => {
    const n = [{ id: uid(), src }, ...store.images].slice(0, 12);
    if (!(await saveKV("testimonials", n))) throw new Error("save");
  };
  const delTesti = (id) => saveKV("testimonials", store.images.filter((t) => t.id !== id));
  const saveOrder = async (o) => {
    o.createdAt = o.createdAt || Date.now();
    try { await DB.put("orders", o); setOrders((p) => p.some((x) => x.id === o.id) ? p.map((x) => x.id === o.id ? o : x) : p.concat(o)); toast(L("Pesanan tersimpan", "Order saved")); return true; }
    catch (e) { toast(L("Gagal menyimpan pesanan", "Could not save the order")); return false; }
  };
  const delOrder = async (id) => { try { await DB.del("orders", id); setOrders((p) => p.filter((x) => x.id !== id)); } catch (e) { toast(L("Gagal menghapus", "Could not delete")); } };
  const saveTpl = async (t) => {
    t.createdAt = t.createdAt || Date.now();
    try { await DB.put("templates", t); setTemplates((p) => p.some((x) => x.id === t.id) ? p.map((x) => x.id === t.id ? t : x) : p.concat(t)); toast(L("Template tersimpan", "Template saved")); return true; }
    catch (e) { toast(L("Gagal menyimpan template", "Could not save the template")); return false; }
  };
  const delTpl = async (id) => { try { await DB.del("templates", id); setTemplates((p) => p.filter((x) => x.id !== id)); } catch (e) { toast(L("Gagal menghapus", "Could not delete")); } };
  const saveAdminKV = async (k, v) => {
    try { await DB.setAdminKV(k, v); setAdminKV((p) => ({ ...p, [k]: v })); return true; }
    catch (e) { toast(L("Gagal menyimpan", "Could not save")); return false; }
  };
  const logout = async () => { await supabase.auth.signOut(); await session.refresh(); };

  const products = useMemo(() => toolProducts(store.catalog), [store.catalog]);
  const A = { lang, L, setLang, go, admin: true, logout, changePin: changeAuthPin, adminKV, saveAdminKV,
    profile: store.profile, setProfile, custom: [], products, testi: store.images, addTesti, delTesti,
    orders, saveOrder, delOrder, templates, saveTpl, delTpl };

  const view = tab === "orders" ? <Orders /> : tab === "catalog" ? <CatalogEditor /> : tab === "studio" ? <Studio />
    : tab === "templates" ? <Templates /> : tab === "testimonials" ? <TestimonialsAdmin /> : <Settings />;

  return (
    <AppCtx.Provider value={A}>
      <div className="admin-strip">
        <span className="muted">{session.email}</span>
        <Button variant="outline" size="sm" onClick={logout}>{L("Keluar", "Log out")}</Button>
      </div>
      <div className="admin-tabs" role="group" aria-label="Admin">
        {TABS.map(([k, icon, id, en]) => (
          <Button key={k} size="sm" variant={tab === k ? "default" : "outline"} onClick={() => go(k)} aria-pressed={tab === k}>{icon} {L(id, en)}</Button>
        ))}
      </div>
      <div className="admin-body" key={tab}>{view}</div>
    </AppCtx.Provider>
  );
}
