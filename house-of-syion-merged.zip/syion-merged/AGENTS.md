<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- UI is the "new mode" storefront: SSR routes `/`, `/order/$appId`, `/profile`, `/contact`, `/testimonials` inside `StoreShell`. The admin tools (Orders, Catalog editor, Watermark Studio, Templates, Testimonials, Settings) are client-only in `src/syion/*.tsx` (`// @ts-nocheck`, hash tabs) mounted at `/admin` behind `ClientOnly`; they use canvas/localStorage/clipboard, so never SSR them.
- Admin access = `admin` row in `public.user_roles`; the first account ever created becomes admin via a trigger on auth.users. All RLS checks `has_role`, never "any signed-in user".
- Public storefront content lives in `kv` (anon-readable); admin-only settings (Sheets webhook, reminder recipient/sender) live in `admin_kv`. Never put private data in `kv`.
- Expiry reminders run from `/api/public/jobs/expiry-reminder` (managed HTTP schedule, cron-auth) and send through the Resend connector gateway.
- Styling: `src/styles.css` = new-mode theme (oklch tokens, `.dark`) plus a restyle of the old tool classes. Tailwind preflight is now imported; old tool classes rely on the explicit base styles in that file.
- The price catalog lives in kv key `catalog` (written by the catalog editor, validated by `src/lib/catalog-schema.ts`). Until it is saved once, `buildStore` in `src/lib/store-model.ts` merges the default catalog with legacy kv keys (`custom_products`, `catalog_overrides`); legacy keys are never deleted.
- Text testimonials use table `testimonials` (`drizzle/migrations/0001_testimonials.sql`); the UI degrades gracefully when it is missing.

- Catalog base products use ID-keyed public overrides; custom products own stable field definitions, and orders snapshot definitions plus private values to preserve history after product edits.
- Subscription expiry and card state use pure date-fns helpers in src/syion/order-state.ts so calendar months, custom days and warranty rules are tested together.
- Ported button calls use the shared Button with a syion variant and size to retain legacy CSS without bypassing the design system.
