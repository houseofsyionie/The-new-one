create type public.app_role as enum ('admin', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "users read own roles" on public.user_roles for select to authenticated using (user_id = auth.uid());

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

-- The first account ever created becomes the shop admin. Later sign-ups get no access.
create or replace function public.claim_first_admin()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  perform pg_advisory_xact_lock(424242);
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  end if;
  return new;
end $$;
create trigger on_auth_user_created_claim_admin after insert on auth.users
  for each row execute function public.claim_first_admin();

create or replace function public.admin_exists()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where role = 'admin') $$;
grant execute on function public.admin_exists() to anon, authenticated;

create table public.kv (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
grant select on public.kv to anon, authenticated;
grant insert, update, delete on public.kv to authenticated;
grant all on public.kv to service_role;
alter table public.kv enable row level security;
create policy "kv public read" on public.kv for select using (true);
create policy "kv admin insert" on public.kv for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "kv admin update" on public.kv for update to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
create policy "kv admin delete" on public.kv for delete to authenticated using (public.has_role(auth.uid(), 'admin'));

create table public.admin_kv (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.admin_kv to authenticated;
grant all on public.admin_kv to service_role;
alter table public.admin_kv enable row level security;
create policy "admin_kv admin only" on public.admin_kv for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create table public.orders (
  id text primary key,
  data jsonb not null,
  order_date date,
  expires_at date,
  duration_days integer not null default 0,
  remind_sent boolean not null default false,
  created_at timestamptz not null default now()
);
create index orders_expires_idx on public.orders (expires_at) where remind_sent = false;
grant select, insert, update, delete on public.orders to authenticated;
grant all on public.orders to service_role;
alter table public.orders enable row level security;
create policy "orders admin only" on public.orders for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create table public.templates (
  id text primary key,
  data jsonb not null,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.templates to authenticated;
grant all on public.templates to service_role;
alter table public.templates enable row level security;
create policy "templates admin only" on public.templates for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

-- Changing the expiry date re-arms the reminder.
create or replace function public.orders_rearm_reminder()
returns trigger language plpgsql set search_path = public
as $$ begin
  if tg_op = 'UPDATE' and new.expires_at is distinct from old.expires_at then new.remind_sent := false; end if;
  return new;
end $$;
create trigger orders_rearm before update on public.orders for each row execute function public.orders_rearm_reminder();