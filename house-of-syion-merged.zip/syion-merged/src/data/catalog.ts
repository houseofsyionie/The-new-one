export type Variant = { type: string; duration: string; price: number };
export type OrderField = { id: string; label: string; type: 'text' | 'number' | 'date' | 'textarea'; required: boolean };
export type AppItem = { id: string; name: string; category: string; active: boolean; note?: string | undefined; icon?: string | undefined; fields?: OrderField[] | undefined; variants: Variant[] };
export type StoreSettings = { title?: string | undefined; bannerUrl?: string | undefined; theme?: 'lavender' | 'midnight' | undefined };
export type Catalog = { categories: string[]; apps: AppItem[]; settings?: StoreSettings | undefined };
export const guessIcon = (name: string, category: string): string => {
  const n = name.toLowerCase();
  if (/netflix|streaming|disney|hbo|prime|vidio/.test(n)) return '🎬';
  if (/canva|design|capcut|alight/.test(n)) return '🎨';
  if (/chatgpt|claude|gemini|grok|\bai\b/.test(n)) return '🤖';
  if (/getcontact|check|lookup/.test(n)) return '🔍';
  if (/music|spotify/.test(n)) return '🎧';
  if (category.startsWith('Streaming')) return '📺';
  if (category.startsWith('Design')) return '✨';
  return '📦';
};

const v = (type: string, rows: [string, number][]): Variant[] =>
  rows.map(([duration, k]) => ({ type, duration, price: k * 1000 }));

const app = (name: string, category: string, variants: Variant[], note?: string): AppItem => ({
  id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""),
  name, category, active: true, note, variants,
});

const S = "Streaming & Music", A = "AI & Education", D = "Design & Editing", O = "Other";

export const defaultCatalog: Catalog = {
  categories: [S, A, D, O],
  apps: [
    app("Netflix", S, [
      ...v("1 Profile 1 User", [["1 Hari", 6], ["2 Hari", 10], ["3 Hari", 13], ["5 Hari", 15], ["7 Hari", 20], ["14 Hari", 30], ["1 Bulan", 45], ["2 Bulan", 88], ["3 Bulan", 135]]),
      ...v("Semi Private (2 dev)", [["1 Bulan", 55]]),
      ...v("Anti Limit", [["1 Bulan", 60]]),
      ...v("Private Basic (Single screen)", [["1 Bulan", 70]]),
      ...v("Private Premium", [["1 Bulan", 200]]),
    ]),
    app("Disney+", S, [
      ...v("Premium Plan Sharing", [["1 Hari", 6], ["3 Hari", 13], ["5 Hari", 15], ["7 Hari", 20], ["1 Bulan (6U)", 35], ["1 Bulan (3U)", 60]]),
      ...v("Private Premium", [["1 Bulan", 160]]),
      ...v("Private Basic", [["1 Bulan", 90]]),
    ]),
    app("Youtube", S, [
      ...v("Indplan", [["1 Bulan", 20], ["3 Bulan", 60]]),
      ...v("Famplan", [["1 Bulan", 15], ["2 Bulan", 20]]),
      ...v("Famhead", [["1 Bulan", 40]]),
      ...v("Mixplan", [["3 Bulan", 45]]),
    ], "Akun store +6K"),
    app("VIU", S, v("Private Antilimit", [["1 Hari", 4], ["3 Hari", 8], ["7 Hari", 10], ["1 Bulan", 15], ["3 Bulan", 25], ["6 Bulan", 40], ["1 Tahun", 50]])),
    app("WeTV", S, [
      ...v("Sharing 6U", [["1 Hari", 5], ["3 Hari", 8], ["7 Hari", 12], ["1 Bulan", 17], ["3 Bulan", 30]]),
      ...v("Private", [["1 Bulan", 45], ["3 Bulan", 90]]),
    ]),
    app("Loklok", S, [
      ...v("Sharing Basic", [["1 Bulan", 27]]), ...v("Sharing Standard", [["1 Bulan", 35]]),
      ...v("Private Basic", [["1 Bulan", 70]]), ...v("Private Standard", [["1 Bulan", 90]]),
    ], "Standard bisa TV, basic tidak"),
    app("HBO Max", S, [
      ...v("Sharing Ultimate", [["1 Hari", 8], ["3 Hari", 15], ["7 Hari", 20], ["1 Bulan", 35]]),
      ...v("Sharing Standar Mobile", [["1 Bulan", 25]]), ...v("Sharing Standar TV", [["1 Bulan", 30]]),
      ...v("Private Ultimate", [["1 Bulan", 125]]),
    ]),
    app("Crunchyroll", S, v("Sharing", [["1 Bulan", 20]])),
    app("Dramabox", S, v("Sharing", [["1 Bulan", 25]])),
    app("Dramawave", S, v("Private Login Web", [["7 Hari", 35], ["1 Bulan", 70]])),
    app("Viki+", S, [...v("Sharing", [["1 Bulan", 20]]), ...v("Private", [["1 Bulan", 50]])]),
    app("Youku", S, [
      ...v("Sharing", [["1 Bulan", 15], ["3 Bulan", 25], ["6 Bulan", 35], ["1 Tahun", 45]]),
      ...v("Private", [["1 Bulan", 45]]),
    ]),
    app("Apple Music", S, [
      ...v("Famplan", [["1 Bulan", 23], ["2 Bulan", 35], ["3 Bulan", 40], ["4 Bulan", 50]]),
      ...v("Famplan Head", [["1 Bulan", 40]]),
    ], "Support iOS & Android"),
    app("Vision+ Sports", S, v("Private PayTV BeIN", [["1 Hari", 8], ["3 Hari", 15], ["7 Hari", 20], ["1 Bulan", 50]]), "Limit 2 device"),
    app("Bstation", S, [
      ...v("Sharing", [["1 Bulan", 15], ["3 Bulan", 30], ["1 Tahun", 45]]),
      ...v("Private", [["1 Bulan", 45]]),
    ]),
    app("iQIYI", S, [
      ...v("Sharing Antilimit Premium", [["1 Bulan", 30]]), ...v("Sharing Antilimit Standard", [["1 Bulan", 25]]),
      ...v("Sharing 6U Premium", [["1 Bulan", 25]]), ...v("Sharing 6U Standard", [["1 Bulan", 15]]),
      ...v("Private Premium", [["1 Bulan", 45]]), ...v("Private Standard", [["1 Bulan", 40]]),
    ]),
    app("Amazon Prime", S, [
      ...v("Sharing", [["1 Hari", 5], ["3 Hari", 8], ["7 Hari", 12], ["1 Bulan (4-5U)", 15], ["1 Bulan (3U)", 20], ["1 Bulan (2U)", 25]]),
      ...v("Private", [["1 Bulan", 35]]),
    ]),
    app("Vidio Platinum", S, [
      ...v("Private Mobile", [["1 Hari", 10], ["3 Hari", 15], ["7 Hari", 20], ["1 Bulan", 45]]),
      ...v("Private TV", [["1 Hari", 8], ["3 Hari", 12], ["7 Hari", 20], ["1 Bulan", 35]]),
      ...v("Private All Device", [["1 Hari", 15], ["3 Hari", 18], ["7 Hari", 25], ["1 Bulan", 55]]),
    ]),
    app("ChatGPT", A, [
      ...v("Sharing (Plan Go)", [["1 Hari", 10], ["3 Hari", 18], ["5 Hari", 25], ["7 Hari", 30]]),
      ...v("Sharing Plus", [["1 Bulan (6U)", 37], ["1 Bulan (4U)", 40], ["1 Bulan (2U)", 45]]),
      ...v("Private", [["1 Bulan", 80], ["2 Bulan", 150]]),
    ]),
    app("Gemini Pro", A, [
      ...v("Famplan/Invite", [["1 Hari", 10], ["7 Hari", 20], ["1 Bulan", 25], ["2 Bulan", 40], ["3 Bulan", 55], ["4 Bulan", 70]]),
      ...v("Private", [["1 Bulan", 70], ["3 Bulan", 95]]),
    ], "Famplan butuh email customer"),
    app("Super Grok AI", A, [
      ...v("Sharing", [["3 Hari", 6], ["1 Bulan", 25], ["3 Bulan", 60]]),
      ...v("Private", [["3 Hari", 12], ["1 Bulan", 50], ["3 Bulan", 100]]),
    ], "Full garansi"),
    app("Claude AI", A, [...v("Sharing 5U", [["7 Hari", 60]]), ...v("Private", [["7 Hari", 150]])]),
    app("Zoom", A, [
      ...v("100 Participants", [["1 Jam", 7], ["1 Hari", 15], ["7 Hari", 45], ["14 Hari", 55], ["1 Bulan", 75]]),
      ...v("300 Participants", [["1 Jam", 20], ["2 Jam", 25], ["3 Jam", 30], ["1 Hari", 45]]),
    ]),
    app("Grammarly", A, [...v("Sharing 8U", [["7 Hari", 20], ["1 Bulan", 25]]), ...v("Private", [["1 Bulan", 55]])]),
    app("Quillbot", A, v("Sharing 8U", [["1 Bulan", 25]])),
    app("DeepL Pro", A, [...v("Sharing", [["7 Hari", 15], ["1 Bulan", 30]]), ...v("Private", [["7 Hari", 25], ["1 Bulan", 40]])]),
    app("Microsoft 365", A, [
      ...v("Famplan/Invite", [["1 Bulan", 15], ["2 Bulan", 25], ["3 Bulan", 30], ["6 Bulan", 55], ["1 Tahun", 65]]),
      ...v("Head", [["1 Bulan", 45]]),
    ]),
    app("Canva Pro", D, [
      ...v("Renewal / Bulan", [["1 Hari", 3], ["2 Hari", 4], ["3 Hari", 5], ["7 Hari", 8], ["1 Bulan", 12], ["2 Bulan", 14], ["3 Bulan", 17], ["6 Bulan", 30], ["1 Tahun (Full Gar)", 40]]),
      ...v("No Renewal", [["2 Bulan", 25], ["3 Bulan", 30], ["6 Bulan", 45], ["1 Tahun (Gar 6B)", 60], ["1 Tahun (Full Gar)", 70]]),
      ...v("Education", [["Gar 6 Bulan", 35], ["Gar 10 Bulan", 40], ["Gar 1 Tahun", 50]]),
    ], "Designer +2K"),
    app("CapCut Pro", D, [
      ...v("Sharing (Android only)", [["1 Hari", 9], ["3 Hari", 18], ["7 Hari", 25], ["1 Bulan (2U)", 60]]),
      ...v("Private (All device)", [["1 Hari", 15], ["3 Hari", 20], ["7 Hari", 35], ["1 Bulan", 80]]),
    ]),
    app("Dazzcam", D, v("Lifetime (sewa Apple ID)", [["Garansi 6 Bulan", 30], ["Garansi 1 Tahun", 50]])),
    app("Beautyplus", D, v("Sharing", [["iOS 1 Tahun", 34], ["Android 1 Tahun", 36]])),
    app("Meitu", D, v("Private VIP", [["7 Hari", 25]])),
    app("Alight Motion", D, [...v("Sharing", [["1 Bulan", 15], ["1 Tahun", 35]]), ...v("Private", [["1 Bulan", 35], ["1 Tahun", 60]])]),
  ],
};
