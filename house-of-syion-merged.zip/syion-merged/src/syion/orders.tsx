// @ts-nocheck
/* eslint-disable */
import { useState, useEffect, useRef, useMemo, useContext, createContext, Fragment } from "react";
import { supabase } from "@/integrations/supabase/client";
import { calculateExpiry, orderState } from "./order-state";
import { $, AppCtx, DB, DUR_OPTS, Field, ImageModal, KAO, LS, MIN_PIN, Modal, Switch, TAGS, TextModal, ToastHost, UNIT, addDays, addMonths, adminLogin, calcExpiry, cap, changePin, copyText, diffDays, durLabel, ensureFonts, fileURL, fmtDate, h, isAdminUser, isoDate, loadImg, loc, monthLabel, ok, pad, parseDur, parseISO, prodDur, rp, shrink, toast, toastBus, today, uid, unitLabel, useApp, waDigits, waUrl } from "./shared";
/* ================= orders ================= */

export function plainText(o,lang){
  const L=(a,b)=>lang==='id'?a:b;
  return [
    '૮ ˶ᵔ ᵕ ᵔ˶ ა  ✧ HOUSE OF SYION 🎀 ✧',
    '╭────────────⋆⋅☆⋅⋆────────────╮',
    ' ✧ '+L('Aplikasi','App')+' : '+o.app,
    ' ✧ '+L('Tipe','Type')+' : '+(o.type==='Private'?'Private':'Sharing'),
    ' ✧ '+L('Durasi','Duration')+' : '+durLabel(o,lang),
    ' ✧ Email : '+(o.email||'-'),
    ' ✧ Password : '+(o.password||'-'),
    ' ✧ '+L('Aktif sampai','Active until')+' : '+fmtDate(o.expires,lang),
    '╰────────────⋆⋅☆⋅⋆────────────╯',
    ' ₍ᐢ. .ᐢ₎ ♡ '+L('Terima kasih ya kak, selamat menikmati!','Thank you, enjoy your app!')
  ].join('\n');
}

export async function makeReceipt(o,lang){
  await ensureFonts();
  const L=(a,b)=>lang==='id'?a:b,W=760,rows=[
    [L('Tanggal','Date'),fmtDate(o.date,lang)],[L('Pembeli','Buyer'),o.buyer||'-'],[L('Aplikasi','App'),o.app],
    [L('Tipe','Type'),o.type==='Private'?'Private':'Sharing'],[L('Durasi','Duration'),durLabel(o,lang)],
    [L('Aktif sampai','Active until'),fmtDate(o.expires,lang)],[L('Perpanjangan','Renewal'),o.renewal?L('Ya','Yes'):L('Tidak','No')],
    [L('Harga','Price'),rp(o.price)],[L('Pembayaran','Payment'),o.status==='Paid'?L('Lunas','Paid'):o.status==='DP'?'DP':L('Belum bayar','Unpaid')]];
  const H=420+rows.length*58;
  const c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d');
  const g=x.createLinearGradient(0,0,W,H);g.addColorStop(0,'#2a2470');g.addColorStop(.55,'#3B3486');g.addColorStop(1,'#7a63d0');x.fillStyle=g;x.fillRect(0,0,W,H);
  let s=11;const r=()=>{s=(s*9301+49297)%233280;return s/233280};
  const cols=['#FFF38B','#ffffff','#FFB8D0','#A2E1FF'];
  for(let i=0;i<70;i++){x.fillStyle=cols[i%4];x.globalAlpha=.35+r()*.6;const px=r()*W,py=r()*H,q=2+r()*5;x.beginPath();for(let k=0;k<8;k++){const a=k*Math.PI/4,rr=k%2?q*.3:q;x.lineTo(px+Math.cos(a)*rr,py+Math.sin(a)*rr)}x.closePath();x.fill()}
  x.globalAlpha=1;
  const px=40,py=70,pw=W-80,ph=H-140;
  x.fillStyle='rgba(255,255,255,.93)';x.strokeStyle='#A2E1FF';x.lineWidth=5;
  x.beginPath();x.roundRect?x.roundRect(px,py,pw,ph,34):x.rect(px,py,pw,ph);x.fill();x.stroke();
  x.fillStyle='#FFB8D0';
  for(let k=0;k<Math.floor(pw/30);k++){x.beginPath();x.arc(px+15+k*30,py,14,0,Math.PI);x.fill();x.beginPath();x.arc(px+15+k*30,py+ph,14,Math.PI,0);x.fill()}
  x.textAlign='center';x.textBaseline='alphabetic';
  x.fillStyle='#3B3486';x.font='44px Chewy,"Baloo 2",sans-serif';x.fillText('HOUSE OF SYION 🎀',W/2,py+84);
  x.font='700 22px "Baloo 2",sans-serif';x.fillStyle='#8a7fd0';x.fillText('✧ DIGITAL RECEIPT ✧',W/2,py+120);
  x.strokeStyle='#D6C5F0';x.setLineDash([8,8]);x.lineWidth=3;x.beginPath();x.moveTo(px+30,py+146);x.lineTo(px+pw-30,py+146);x.stroke();x.setLineDash([]);
  let y=py+196;
  rows.forEach(([k,v],i)=>{
    x.textAlign='left';x.fillStyle='#7d72c4';x.font='700 22px Quicksand,"Baloo 2",sans-serif';x.fillText(k,px+36,y);
    x.textAlign='right';x.fillStyle='#3B3486';x.font='700 26px Quicksand,"Baloo 2",sans-serif';
    let t=String(v);while(x.measureText(t).width>pw-260&&t.length>4)t=t.slice(0,-2);if(t!==String(v))t+='…';
    x.fillText(t,px+pw-36,y);y+=58;
  });
  x.textAlign='center';x.fillStyle='#3B3486';x.font='38px "Baloo 2",sans-serif';x.fillText('૮ ˶ᵔ ᵕ ᵔ˶ ა',W/2,y+30);
  x.font='700 22px Quicksand,"Baloo 2",sans-serif';x.fillStyle='#8a7fd0';x.fillText(L('Terima kasih sudah belanja ya kak!','Thank you for shopping with us!'),W/2,y+68);
  x.font='700 16px Quicksand,sans-serif';x.fillText('No. '+o.id.slice(0,8).toUpperCase(),W/2,H-86);
  const blob=await new Promise(res=>c.toBlob(res,'image/png'));
  return{name:'receipt-'+(o.buyer||'syion').replace(/\W+/g,'-')+'-'+o.date+'.png',url:URL.createObjectURL(blob)};
}

export const blankOrder=(app='')=>({id:uid(),date:today(),app,appCustom:'',type:'Sharing',dur:'1m',durN:1,durU:'d',renewal:false,buyer:'',wa:'',device:'',price:'',modal:'',email:'',password:'',fh:'',fhWa:'',status:'Unpaid',hasProof:false,proof:null});

export function OrderForm({init,onClose}){
  const A=useApp(),L=A.L;
  const [f,setF]=useState(init);const [pw,setPw]=useState(false);const [busy,setBusy]=useState(false);
  const set=(k,v)=>setF(p=>({...p,[k]:v}));
  const isCustom=f.app==='__custom';
  const product=A.products.find(p=>p.id===f.productId)||A.products.find(p=>p.name===f.app);
  const customFields=product?.fields||f.fieldDefinitions||[];
  const profit=(Number(f.price)||0)-(Number(f.modal)||0);
  const names=A.products.map(p=>p.name);
  const save=async e=>{
    e.preventDefault();
    const app=isCustom?(f.appCustom||'').trim():f.app;
    if(f.customDays!==undefined&&f.customDays!==''&&(!Number.isInteger(Number(f.customDays))||Number(f.customDays)<1)){toast(L('Jumlah hari harus bilangan bulat positif','Days must be a positive whole number'));return}
    if(!app){toast(L('Isi nama aplikasi dulu','Enter an app name'));return}
    const ex=calcExpiry(f.date,f);
    const o={...f,app,productId:product?.id,fieldDefinitions:customFields,price:Number(f.price)||0,modal:Number(f.modal)||0,profit,expires:ex.expires,durDays:ex.days,proof:f.hasProof?f.proof:null};
    delete o.appCustom;
    setBusy(true);const ok=await A.saveOrder(o);setBusy(false);if(ok)onClose();
  };
  const pickProof=async e=>{const file=e.target.files[0];e.target.value='';if(!file)return;try{const proof=await shrink(fileURL(file),900,.78);setF(p=>({...p,proof,hasProof:true}))}catch(x){toast(L('Gambar gagal dibaca','Could not read the image'))}};
  return h(Modal,{title:init.createdAt?L('Ubah Pesanan','Edit Order'):L('Pesanan Baru','New Order'),onClose,wide:true},
    $.form({className:'stack',onSubmit:save},
      $.div({className:'form-grid'},
        h(Field,{label:L('Tanggal','Date')},$.input({id:'o-date',type:'date',required:true,value:f.date,onChange:e=>set('date',e.target.value)})),
        h(Field,{label:L('Nama Aplikasi','App Name')},$.select({id:'o-app',value:f.app,onChange:e=>{const p=A.products.find(x=>x.name===e.target.value);setF(old=>({...old,app:e.target.value,productId:p?.id,customValues:{},fieldDefinitions:[]}))}},names.map(n=>$.option({key:n,value:n},n)),$.option({value:'__custom'},L('Lainnya (ketik sendiri)','Custom (type it)')))),
        isCustom?h(Field,{label:L('Nama Aplikasi Custom','Custom App Name')},$.input({id:'o-app-c',type:'text',value:f.appCustom,onChange:e=>set('appCustom',e.target.value)})):null,
        h(Field,{label:L('Tipe','Type')},$.div({className:'radios'},['Sharing','Private'].map(t=>$.button({key:t,type:'button','aria-pressed':f.type===t,onClick:()=>set('type',t)},t)))),
        h(Field,{label:L('Durasi','Duration')},$.select({id:'o-dur',value:f.dur,onChange:e=>set('dur',e.target.value)},DUR_OPTS.map(d=>$.option({key:d,value:d},d==='custom'?L('Custom','Custom'):durLabel({dur:d},A.lang))))),
        f.dur==='custom'?h(Field,{label:L('Durasi Custom','Custom Duration')},$.div({className:'row',style:{flexWrap:'nowrap'}},
          $.input({id:'o-durn',type:'number',min:1,value:f.durN,onChange:e=>set('durN',e.target.value)}),
          $.select({id:'o-duru',value:f.durU,onChange:e=>set('durU',e.target.value)},Object.keys(UNIT).map(u=>$.option({key:u,value:u},cap(UNIT[u][A.lang==='id'?0:1])))))):null,
        h(Field,{label:L('Jumlah hari khusus (opsional)','Custom days (optional)')},$.input({id:'o-custom-days',type:'number',min:1,step:1,placeholder:'25 / 28 / 30',value:f.customDays??'',onChange:e=>set('customDays',e.target.value)})),
        $.div({className:'field full period-preview'},L('Aktif sampai: ','Active until: ')+(f.date?fmtDate(calcExpiry(f.date,f).expires,A.lang):'—')),
        customFields.map(x=>h(Field,{key:x.id,label:x.label,full:x.type==='textarea'},h(x.type==='textarea'?'textarea':'input',{id:'custom-'+x.id,type:x.type==='textarea'?undefined:x.type,required:x.required,value:f.customValues?.[x.id]??'',onChange:e=>set('customValues',{...f.customValues,[x.id]:e.target.value})}))),
        h(Field,{plain:true,label:L('Perpanjangan (Renewal)','Renewal')},h(Switch,{id:'o-renew',on:f.renewal,set:v=>set('renewal',v),label:f.renewal?L('Ya','Yes'):L('Tidak','No')})),
        h(Field,{label:L('Inisial Pembeli','Buyer Initial')},$.input({id:'o-buyer',type:'text',value:f.buyer,onChange:e=>set('buyer',e.target.value)})),
        h(Field,{label:L('No. WhatsApp Pembeli','Buyer WhatsApp')},$.input({id:'o-wa',type:'tel',placeholder:'08xxxxxxxxxx',value:f.wa,onChange:e=>set('wa',e.target.value)})),
        h(Field,{label:L('Device / Brand','Device / Brand')},$.input({id:'o-dev',type:'text',value:f.device,onChange:e=>set('device',e.target.value)})),
        h(Field,{label:L('Harga Aplikasi','App Price')},$.input({id:'o-price',type:'number',min:0,value:f.price,onChange:e=>set('price',e.target.value)})),
        h(Field,{label:L('Modal','Capital')},$.input({id:'o-modal',type:'number',min:0,value:f.modal,onChange:e=>set('modal',e.target.value)})),
        h(Field,{label:L('Profit (otomatis)','Profit (auto)')},$.div({className:'pill pill-star',style:{fontSize:'1.1rem',padding:'8px 14px',color:'#3B3486'}},rp(profit))),
        h(Field,{label:'Email'},$.input({id:'o-email',type:'text',autoComplete:'off',value:f.email,onChange:e=>set('email',e.target.value)})),
        h(Field,{label:'Password'},$.div({className:'pw'},$.input({id:'o-pass',type:pw?'text':'password',autoComplete:'new-password',value:f.password,onChange:e=>set('password',e.target.value)}),$.button({type:'button',className:'btn btn-ghost btn-ico','aria-label':pw?'Hide password':'Show password','aria-pressed':pw,onClick:()=>setPw(!pw)},pw?'🙈':'👁'))),
        h(Field,{label:'Admin FH'},$.input({id:'o-fh',type:'text',value:f.fh,onChange:e=>set('fh',e.target.value)})),
        h(Field,{label:L('Kontak Admin FH (WhatsApp)','Admin FH Contact (WhatsApp)')},$.input({id:'o-fhwa',type:'tel',placeholder:'08xxxxxxxxxx',value:f.fhWa,onChange:e=>set('fhWa',e.target.value)})),
        h(Field,{label:L('Status Pembayaran','Payment Status')},$.div({className:'radios'},[['Unpaid',L('Belum bayar','Unpaid')],['DP','DP'],['Paid',L('Lunas','Paid')]].map(s=>$.button({key:s[0],type:'button','aria-pressed':f.status===s[0],onClick:()=>set('status',s[0])},s[1])))),
        h(Field,{plain:true,label:L('Bukti Transfer','Transfer Proof'),full:true},$.div({className:'row'},
          h(Switch,{id:'o-proof',on:f.hasProof,set:v=>set('hasProof',v),label:f.hasProof?L('Unggah bukti','Upload proof'):L('Tanpa bukti','No proof')}),
          f.hasProof?$.input({id:'o-proof-f',type:'file',accept:'image/*',onChange:pickProof,style:{maxWidth:260}}):null,
          f.hasProof&&f.proof?$.img({src:f.proof,alt:'Proof',style:{height:56,borderRadius:10,border:'2px solid var(--glass-brd)'}}):null))),
      $.div({className:'row',style:{justifyContent:'flex-end'}},
        $.button({type:'button',className:'btn btn-ghost',onClick:onClose},L('Batal','Cancel')),
        $.button({type:'submit',className:'btn btn-star',disabled:busy},'💾 '+L('Simpan','Save')))));
}

export function Orders(){
  const A=useApp(),L=A.L;
  const months=useMemo(()=>{const m={};A.orders.forEach(o=>{const k=(o.date||'').slice(0,7);if(k)m[k]=(m[k]||0)+1});return Object.keys(m).sort().reverse().map(k=>[k,m[k]])},[A.orders]);
  const [month,setMonth]=useState(null);const [q,setQ]=useState('');
  const [edit,setEdit]=useState(null),[shown,setShown]=useState({}),[del,setDel]=useState(null),[img,setImg]=useState(null),[manual,setManual]=useState(null),[proof,setProof]=useState(null);
  const cur=month&&months.some(m=>m[0]===month)?month:month==='all'?'all':(months[0]?months[0][0]:'all');
  const rows=useMemo(()=>{
    const s=q.trim().toLowerCase();
    return A.orders.filter(o=>(cur==='all'||(o.date||'').startsWith(cur))&&(!s||[o.app,o.buyer,o.wa,o.email,o.fh,o.fhWa,o.device,o.type,o.status].join(' ').toLowerCase().includes(s))).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||(b.createdAt||0)-(a.createdAt||0));
  },[A.orders,cur,q]);
  const sum=rows.reduce((a,o)=>({price:a.price+(o.price||0),modal:a.modal+(o.modal||0),profit:a.profit+(o.profit||0)}),{price:0,modal:0,profit:0});
  const soon=A.orders.filter(o=>{if(!o.expires||(o.durDays||0)<=31)return false;const d=diffDays(parseISO(today()),parseISO(o.expires));return d>=0&&d<=3}).sort((a,b)=>a.expires.localeCompare(b.expires));
  const stLabel=s=>s==='Paid'?L('Lunas','Paid'):s==='DP'?'DP':L('Belum','Unpaid');
  const copy=async o=>{const t=plainText(o,A.lang);if(await copyText(t))toast(L('Teks tersalin ૮ ˶ᵔ ᵕ ᵔ˶ ა','Text copied ૮ ˶ᵔ ᵕ ᵔ˶ ა'));else setManual(t)};
  const receipt=async o=>{try{setImg([await makeReceipt(o,A.lang)])}catch(e){toast(L('Gagal membuat struk','Could not create the receipt'))}};
  const exportSheets=async()=>{
    const head=['Date','App','Type','Duration','Renewal','Buyer','WhatsApp','Device','Price','Capital','Profit','Email','Password','Admin FH','Admin FH Contact','Payment','Active until'];
    const data=rows.map(o=>[o.date,o.app,o.type,durLabel(o,'en'),o.renewal?'Yes':'No',o.buyer,o.wa,o.device,o.price,o.modal,o.profit,o.email,o.password,o.fh,o.fhWa,o.status,o.expires]);
    if(A.adminKV.sheets_webhook){
      try{await fetch(A.adminKV.sheets_webhook,{method:'POST',mode:'no-cors',headers:{'Content-Type':'text/plain'},body:JSON.stringify({sheet:cur,rows:[head].concat(data)})});toast(L('Dikirim ke Google Sheets','Sent to Google Sheets'));return}catch(e){}
    }
    const tsv=[head].concat(data).map(r=>r.map(c=>String(c==null?'':c).replace(/[\t\r\n]+/g,' ')).join('\t')).join('\n');
    if(await copyText(tsv))toast(L('Data tersalin. Tempel di Google Sheets (Ctrl/Cmd+V)','Copied. Paste into Google Sheets (Ctrl/Cmd+V)'));else setManual(tsv);
  };
  return $.div({className:'stack'},
    $.div({className:'row'},
      $.h2({className:'sec-title'},L('Rekap Pesanan','Order Recap')),
      $.div({className:'row sp'},
        $.a({className:'btn btn-ghost',href:'https://sheets.new',target:'_blank',rel:'noopener',onClick:exportSheets},'📊 '+L('Ekspor ke Google Sheets','Export to Google Sheets')),
        $.button({className:'btn btn-star',onClick:()=>setEdit(blankOrder(names(A)[0]||''))},'＋ '+L('Pesanan Baru','New Order')))),
    soon.length?$.div({className:'warnbox',role:'status'},$.b('⏰ '+L('Segera berakhir (≤ 3 hari): ','Expiring soon (≤ 3 days): ')),soon.map(o=>o.app+' · '+(o.buyer||'-')+' · '+fmtDate(o.expires,A.lang)).join('   |   ')):null,
    $.div({className:'chips',role:'group','aria-label':L('Bulan','Month')},
      months.map(m=>$.button({key:m[0],className:'chip','aria-pressed':cur===m[0],onClick:()=>setMonth(m[0])},monthLabel(m[0],A.lang)+' · '+m[1])).concat([$.button({key:'all',className:'chip','aria-pressed':cur==='all',onClick:()=>setMonth('all')},L('Semua bulan','All months'))])),
    $.div({className:'row'},
      $.input({id:'o-search',type:'search',placeholder:'🔍 '+L('Cari pembeli, aplikasi, email…','Search buyer, app, email…'),value:q,onChange:e=>setQ(e.target.value),style:{maxWidth:360},'aria-label':L('Cari','Search')}),
      $.div({className:'bar sp'},$.span(rows.length+' '+L('pesanan','orders')),$.span(L('Omzet','Revenue')+' ',$.b(rp(sum.price))),$.span(L('Modal','Capital')+' ',$.b(rp(sum.modal))),$.span('Profit ',$.b(rp(sum.profit))))),
    rows.length?$.div({className:'order-list'},rows.map(o=>{
      const state=orderState(o,today()),tone=state.status==='Active'?'active':state.status==='Needs Renewal'?'renewal':'expired';
      const detail=(label,value)=>$.div({className:'order-detail'},$.dt(label),$.dd(value||'—'));
      return $.article({key:o.id,className:'glass order-card','aria-label':o.app+' '+(o.buyer||'')},
        $.div({className:'order-heading'},$.div({className:'stack'},$.h3(o.app),$.div({className:'row'},$.span({className:'pill pill-cyan'},o.type),$.span({className:'order-status '+tone},state.status),$.span({className:'warranty '+(state.warranty?'active':'inactive')},state.warranty?'୨୧ Garansi Aktif':'୨୧ Garansi Tidak Aktif'))),
          $.div({className:'remaining','aria-label':state.percentage+'% remaining'},$.svg({viewBox:'0 0 80 80','aria-hidden':'true'},$.circle({className:'progress-track',cx:40,cy:40,r:32}),$.circle({className:'progress-fill '+tone,cx:40,cy:40,r:32,pathLength:100,strokeDasharray:state.percentage+' 100'})),$.b(state.percentage+'%'))),
        $.div({className:'order-period'},$.b(fmtDate(o.date,A.lang)+' → '+fmtDate(o.expires,A.lang)),$.span(durLabel(o,A.lang)+' · '+state.remaining+' '+L('hari tersisa','days remaining'))),
        $.dl({className:'order-details'},
          detail(L('Pembeli','Buyer'),o.buyer),detail('WhatsApp',o.wa?$.a({href:waUrl(o.wa),target:'_blank',rel:'noopener'},o.wa):null),detail('Device',o.device),
          detail(L('Harga','Price'),rp(o.price)),detail(L('Modal','Capital'),rp(o.modal)),detail('Profit',rp(o.profit)),detail('Email',o.email),
          detail('Password',o.password?$.div({className:'row'},$.span(shown[o.id]?o.password:'••••••'),$.button({className:'btn btn-ghost btn-ico','aria-label':shown[o.id]?'Hide password':'Show password',onClick:()=>setShown(p=>({...p,[o.id]:!p[o.id]}))},shown[o.id]?'🙈':'👁')):null),
          detail('Admin FH',o.fh),detail('FH WhatsApp',o.fhWa?$.a({href:waUrl(o.fhWa),target:'_blank',rel:'noopener'},o.fhWa):null),detail(L('Pembayaran','Payment'),$.span({className:'st st-'+(o.status||'Unpaid').toLowerCase()},stLabel(o.status))),detail('Renewal',o.renewal?L('Ya','Yes'):L('Tidak','No')),
          (o.fieldDefinitions||[]).map(x=>h(Fragment,{key:x.id},detail(x.label,o.customValues?.[x.id])))),
        $.div({className:'order-actions'},
          o.proof?$.button({className:'btn btn-ghost btn-sm',onClick:()=>setProof([{url:o.proof,name:'proof.jpg'}])},'🧾 '+L('Bukti TF','Transfer proof')):null,
          $.button({className:'btn btn-ghost btn-ico',title:L('Salin teks cantik','Copy aesthetic text'),'aria-label':L('Salin teks cantik','Copy aesthetic text'),onClick:()=>copy(o)},'📋'),
          $.button({className:'btn btn-ghost btn-ico',title:L('Buat struk','Receipt'),'aria-label':L('Buat struk','Receipt'),onClick:()=>receipt(o)},'🧾'),
          $.button({className:'btn btn-ghost btn-ico',title:L('Ubah','Edit'),'aria-label':L('Ubah','Edit'),onClick:()=>{const known=names(A).find(n=>n.toLowerCase()===String(o.app||'').toLowerCase());setEdit({...o,hasProof:o.hasProof??!!o.proof,appCustom:known?'':o.app,app:known||'__custom'})}},'✎'),
          del===o.id?$.button({className:'btn btn-danger btn-sm',onClick:()=>{A.delOrder(o.id);setDel(null)}},L('Yakin?','Sure?')):$.button({className:'btn btn-danger btn-ico','aria-label':L('Hapus','Delete'),onClick:()=>{setDel(o.id);setTimeout(()=>setDel(null),3000)}},'🗑')));
    }))
    :$.div({className:'glass pad muted',style:{textAlign:'center'}},A.orders.length?L('Tidak ada pesanan yang cocok.','No matching orders.'):L('Belum ada pesanan. Tekan “＋ Pesanan Baru” untuk mulai ✨','No orders yet. Press “＋ New Order” to start ✨')),
    edit?h(OrderForm,{init:edit,onClose:()=>setEdit(null)}):null,
    img?h(ImageModal,{results:img,onClose:()=>setImg(null),title:L('Struk Digital','Digital Receipt')}):null,
    proof?h(ImageModal,{results:proof,onClose:()=>setProof(null),title:L('Bukti Transfer','Transfer Proof')}):null,
    manual?h(TextModal,{text:manual,onClose:()=>setManual(null)}):null);
}
export const names=A=>A.products.map(p=>p.name);
