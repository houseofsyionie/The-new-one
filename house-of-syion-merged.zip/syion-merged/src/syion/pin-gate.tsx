// @ts-nocheck
/* eslint-disable */
import { useState, useEffect, useRef, useMemo, useContext, createContext, Fragment } from "react";
import { supabase } from "@/integrations/supabase/client";
import { calculateExpiry, orderState } from "./order-state";
import { $, AppCtx, DB, DUR_OPTS, Field, ImageModal, KAO, LS, MIN_PIN, Modal, Switch, TAGS, TextModal, ToastHost, UNIT, addDays, addMonths, adminLogin, calcExpiry, cap, changePin, copyText, diffDays, durLabel, ensureFonts, fileURL, fmtDate, h, isAdminUser, isoDate, loadImg, loc, monthLabel, ok, pad, parseDur, parseISO, prodDur, rp, shrink, toast, toastBus, today, uid, unitLabel, useApp, waDigits, waUrl } from "./shared";
/* ================= PIN gate ================= */
export function PinGate(){
  const A=useApp(),L=A.L;
  const [email,setEmail]=useState(()=>LS.get('admin_email',''));
  const [pin,setPin]=useState(''),[err,setErr]=useState(''),[info,setInfo]=useState(''),[busy,setBusy]=useState(false);
  const [setup,setSetup]=useState(false);
  const fails=useRef({n:0,until:0});
  useEffect(()=>{supabase.rpc('admin_exists').then(r=>{if(!r.error&&r.data===false)setSetup(true)})},[]);
  const submit=async e=>{
    e.preventDefault();const f=fails.current;setErr('');setInfo('');
    if(!email.trim()){setErr(L('Isi email admin dulu','Enter the admin email'));return}
    if(setup){
      if(pin.length<MIN_PIN){setErr(L('PIN minimal '+MIN_PIN+' angka','PIN needs at least '+MIN_PIN+' digits'));return}
      setBusy(true);
      const {error}=await supabase.auth.signUp({email:email.trim(),password:pin,options:{emailRedirectTo:window.location.origin}});
      setBusy(false);
      if(error){setErr(error.message);return}
      LS.set('admin_email',email.trim());setSetup(false);setPin('');
      setInfo(L('Cek email kamu dan klik link konfirmasi, lalu masuk dengan PIN ini.','Check your email and click the confirmation link, then sign in with this PIN.'));
      return;
    }
    if(Date.now()<f.until){setErr(L('Terlalu banyak percobaan. Tunggu 30 detik ya.','Too many tries. Please wait 30 seconds.'));return}
    setBusy(true);const r=await A.login(email,pin);setBusy(false);
    if(r==='ok'){LS.set('admin_email',email.trim());return}
    if(r==='unconfirmed'){setErr(L('Email belum dikonfirmasi. Cek inbox kamu ya.','Email not confirmed yet. Please check your inbox.'));return}
    if(r==='notadmin'){setErr(L('Akun ini bukan admin toko.','This account is not the shop admin.'));setPin('');return}
    f.n++;if(f.n>=5){f.until=Date.now()+30000;f.n=0}setErr(L('PIN salah, coba lagi ya 🥺','Wrong PIN, try again 🥺'));setPin('');
  };
  return $.form({className:'glass pad stack',style:{maxWidth:380,margin:'40px auto',textAlign:'center'},onSubmit:submit},
    $.div({style:{fontSize:'2.6rem'}},setup?'🎀':'🔐'),
    $.h2(setup?L('Buat Akun Admin','Create Admin Account'):L('Ruang Admin','Admin Room')),
    $.p({className:'muted'},setup
      ?L('Belum ada admin. Pilih email dan PIN (min. '+MIN_PIN+' angka) untuk akun admin toko.','No admin yet. Pick an email and a PIN (at least '+MIN_PIN+' digits) for the shop admin account.')
      :L('Masukkan email & PIN untuk membuka dashboard.','Enter your email & PIN to open the dashboard.')),
    $.input({id:'admin-email',type:'email',autoComplete:'email','aria-label':'Email',placeholder:'email@contoh.com',value:email,onChange:e=>{setEmail(e.target.value);setErr('')}}),
    $.input({id:'pin',type:'password',inputMode:'numeric',autoComplete:setup?'new-password':'current-password','aria-label':'PIN',value:pin,onChange:e=>{setPin(e.target.value);setErr('')},style:{textAlign:'center',letterSpacing:'.4em',fontSize:'1.3rem'},autoFocus:true}),
    err?$.p({role:'alert',style:{color:'var(--danger)',fontWeight:700}},err):null,
    info?$.p({role:'status',style:{color:'var(--ok)',fontWeight:700}},info):null,
    $.button({className:'btn btn-star',type:'submit',disabled:busy||!pin},busy?'…':(setup?L('Buat akun','Create account'):L('Buka','Unlock'))+' ✨'));
}
