import { describe, expect, it } from 'vitest';
import { calculateExpiry, orderState } from '@/syion/order-state';

describe('Precise subscription periods', () => {
  it('uses calendar months instead of fixed 30 days', () => {
    expect(calculateExpiry('2026-02-01', { dur: '1m' })).toEqual({ expires: '2026-03-01', days: 28 });
    expect(calculateExpiry('2026-01-31', { dur: '1m' })).toEqual({ expires: '2026-02-28', days: 28 });
  });
  it.each([25, 28, 30])('supports exactly %i custom days', days => {
    expect(calculateExpiry('2026-10-01', { dur: '1m', customDays: days })).toEqual({ expires: `2026-10-${days + 1}`, days });
  });
  it('calculates remaining percentage and renewal status', () => {
    expect(orderState({ date: '2026-10-01', expires: '2026-10-31' }, '2026-10-16')).toMatchObject({ percentage: 50, status: 'Active' });
    expect(orderState({ expires: '2026-10-31' }, '2026-10-28').status).toBe('Needs Renewal');
    expect(orderState({ expires: '2026-10-31' }, '2026-10-31').status).toBe('Expired');
  });
  it('links warranty to proof ON and respects OFF', () => {
    expect(orderState({ hasProof: true }, '2026-10-28').warranty).toBe(true);
    expect(orderState({ hasProof: false, proof: 'old-image' }, '2026-10-28').warranty).toBe(false);
    expect(orderState({ proof: 'legacy-image' }, '2026-10-28').warranty).toBe(true);
  });
});