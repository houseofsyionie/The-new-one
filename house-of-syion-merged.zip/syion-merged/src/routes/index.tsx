import { createFileRoute, Link } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { Search, ArrowUpRight, Sparkles } from 'lucide-react';
import { StoreShell } from '@/components/StoreShell';
import { AdminHeroControls } from '@/components/AdminHeroControls';
import { Button } from '@/components/ui/button';
import { storeOptions, useStore, lowestPrice, rupiah } from '@/lib/store';
import { usePrefs } from '@/lib/prefs';
import { useAdminSession } from '@/lib/admin-session';
import { guessIcon } from '@/data/catalog';
import { pageHead } from '@/lib/metadata';
import { Welcome } from '@/syion/welcome';

export const Route = createFileRoute('/')({
  loader: ({ context }) => context.queryClient.ensureQueryData(storeOptions),
  head: () => pageHead('Premium Apps', 'Daftar harga aplikasi premium Syionie. Pilih aplikasi dan pesan melalui WhatsApp.'),
  component: Index,
});

function Index() {
  const { catalog, profile } = useStore();
  const { t } = usePrefs();
  const session = useAdminSession();
  const [tab, setTab] = useState('all');
  const [search, setSearch] = useState('');
  const [welcome, setWelcome] = useState(false);

  // The greeting and shop rules show once per visit, like the original shop.
  useEffect(() => {
    try {
      if (!sessionStorage.getItem('syion:welcomed')) setWelcome(true);
    } catch {
      setWelcome(true);
    }
  }, []);
  const closeWelcome = () => {
    try {
      sessionStorage.setItem('syion:welcomed', '1');
    } catch {
      /* ignore */
    }
    setWelcome(false);
  };

  const apps = catalog.apps.filter((a) => (tab === 'all' || a.category === tab) && a.name.toLowerCase().includes(search.toLowerCase()));
  const banner = profile.banner || catalog.settings?.bannerUrl || '';

  return (
    <StoreShell>
      {session.admin && <AdminHeroControls />}
      <div className="search-field">
        <Search size={16} />
        <input aria-label={t('Cari aplikasi', 'Search apps')} placeholder={t('Cari aplikasi favoritmu...', 'Search your favourite app...')} value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      <section className="store-hero">
        {banner ? <img src={banner} alt="" /> : <div className="hero-art" aria-hidden="true" />}
        <div className="hero-copy">
          <p className="eyebrow">A CURATED LITTLE UNIVERSE</p>
          <h1>{catalog.settings?.title || 'House of Syion'}</h1>
          <p>{profile.bio || t('Aplikasi favoritmu, dengan sentuhan sihir.', 'Your favorite apps, a little more magical.')}</p>
          <small>PREMIUM APPS　✧　WITH LOVE & CALM</small>
        </div>
      </section>
      <div className="collection-heading">
        <div>
          <p className="eyebrow">THE STARLIGHT COLLECTION</p>
          <h2 className="font-display">{t('Temukan sihir harianmu', 'Find your everyday magic')}</h2>
        </div>
        <small>
          {apps.length} {t('aplikasi', 'apps')}
        </small>
      </div>
      <div className="category-tabs">
        {['all', ...catalog.categories].map((c) => (
          <Button size="sm" variant={tab === c ? 'default' : 'outline'} key={c} onClick={() => setTab(c)}>
            <Sparkles />
            {c === 'all' ? t('Semua aplikasi', 'All apps') : c}
          </Button>
        ))}
      </div>
      <div className="app-grid">
        {apps.map((a) => {
          const from = lowestPrice(a);
          return (
            <article className="app-card" key={a.id}>
              <div className="app-card-top">
                <span className="app-icon">{a.icon || guessIcon(a.name, a.category)}</span>
                <small>• {a.active ? t('Tersedia', 'Available') : t('Tutup', 'Closed')}</small>
              </div>
              <h3>{a.name}</h3>
              <p>{a.category}</p>
              <div className="variant-tags">
                {[...new Set(a.variants.map((v) => v.type))].slice(0, 2).map((ty) => (
                  <span key={ty}>{ty}</span>
                ))}
              </div>
              <div className="app-card-bottom">
                <div>
                  <small>{t('mulai dari', 'from')}</small>
                  {from > 0 ? <strong>Rp {rupiah(from)}</strong> : <strong className="ask">{t('Tanya admin', 'Ask admin')}</strong>}
                </div>
                {a.active ? (
                  <Button asChild size="sm">
                    <Link to="/order/$appId" params={{ appId: a.id }}>
                      Order
                      <ArrowUpRight />
                    </Link>
                  </Button>
                ) : (
                  <Button disabled size="sm">
                    {t('Tutup', 'Closed')}
                  </Button>
                )}
              </div>
            </article>
          );
        })}
      </div>
      {!apps.length && <p className="empty-state">{t('Aplikasi tidak ditemukan.', 'No apps found.')}</p>}
      {welcome && <Welcome onClose={closeWelcome} />}
    </StoreShell>
  );
}
