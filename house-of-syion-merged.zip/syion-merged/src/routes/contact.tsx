import { createFileRoute } from '@tanstack/react-router';
import { StoreShell } from '@/components/StoreShell';
import { Button } from '@/components/ui/button';
import { storeOptions, useStore, waDisplay, waLink } from '@/lib/store';
import { usePrefs } from '@/lib/prefs';
import { pageHead } from '@/lib/metadata';

export const Route = createFileRoute('/contact')({
  loader: ({ context }) => context.queryClient.ensureQueryData(storeOptions),
  head: () => pageHead('Contact', 'Hubungi Syionie melalui WhatsApp untuk pesanan aplikasi premium.'),
  component: Contact,
});

function Contact() {
  const { profile } = useStore();
  const { t } = usePrefs();
  const greeting = profile.greeting || t('Halo kak, aku mau tanya-tanya produk di HOUSE OF SYION 🎀', 'Hi! I would like to ask about the products at HOUSE OF SYION 🎀');
  return (
    <StoreShell>
      <div className="page-heading">
        <p className="eyebrow">LET’S KEEP IN TOUCH</p>
        <h1 className="font-display">{t('Kontak', 'Contact')}</h1>
        <p>WhatsApp · {waDisplay(profile)}</p>
        <p>{t('Pembayaran', 'Payment')} · QRIS</p>
      </div>
      <Button asChild>
        <a href={waLink(profile, greeting)} target="_blank" rel="noreferrer">
          {t('Hubungi via WhatsApp', 'Chat on WhatsApp')} ↗
        </a>
      </Button>
    </StoreShell>
  );
}
