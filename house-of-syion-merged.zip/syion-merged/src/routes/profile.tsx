import { createFileRoute } from '@tanstack/react-router';
import { StoreShell } from '@/components/StoreShell';
import { Button } from '@/components/ui/button';
import { storeOptions, useStore, DEFAULT_X } from '@/lib/store';
import { usePrefs } from '@/lib/prefs';
import { pageHead } from '@/lib/metadata';

export const Route = createFileRoute('/profile')({
  loader: ({ context }) => context.queryClient.ensureQueryData(storeOptions),
  head: () => pageHead('Profile / X Info', 'Temui Syionie dan kunjungi profil X @molenkul.'),
  component: Profile,
});

function Profile() {
  const { profile } = useStore();
  const { t } = usePrefs();
  const x = (profile.x || DEFAULT_X).replace(/^@/, '');
  return (
    <StoreShell>
      <div className="page-heading">
        <p className="eyebrow">THE PERSON BEHIND THE MAGIC</p>
        <h1 className="font-display">Syionie ✧</h1>
        <p>House of Syion · @{x}</p>
        {profile.bio && <p>{profile.bio}</p>}
      </div>
      <Button asChild>
        <a href={`https://x.com/${x}`} target="_blank" rel="noreferrer">
          {t('Kunjungi profil X', 'Visit the X profile')} ↗
        </a>
      </Button>
    </StoreShell>
  );
}
