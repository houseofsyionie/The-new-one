// @ts-nocheck
/* eslint-disable */
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "./shared";

/* Moderation for customer text testimonials, plus the watermarked review images made in Watermark Studio. */
export function TestimonialsAdmin() {
  const A = useApp(), L = A.L;
  const [rows, setRows] = useState(null), [enabled, setEnabled] = useState(true), [status, setStatus] = useState("");
  const [sure, setSure] = useState(null);
  const load = async () => {
    const { data, error } = await supabase.from("testimonials").select("id,name,message,approved,created_at").order("created_at", { ascending: false });
    if (error) { setEnabled(false); setRows([]); } else { setEnabled(true); setRows(data || []); }
  };
  useEffect(() => { load(); }, []);
  const toggle = async (row) => {
    const { error } = await supabase.from("testimonials").update({ approved: !row.approved }).eq("id", row.id);
    if (error) setStatus(L("Gagal memperbarui testimoni.", "Could not update the testimonial.")); else await load();
  };
  const remove = async (row) => {
    if (sure !== row.id) { setSure(row.id); setTimeout(() => setSure(null), 3000); return; }
    const { error } = await supabase.from("testimonials").delete().eq("id", row.id);
    setSure(null);
    if (error) setStatus(L("Gagal menghapus.", "Could not delete.")); else await load();
  };
  return (
    <div className="stack">
      <h2 className="sec-title">{L("Testimoni", "Testimonials")}</h2>

      <section className="stack">
        <h3>{L("Screenshot testimoni", "Review screenshots")}</h3>
        <p className="muted">{L("Buat gambar di Watermark Studio, lalu tekan “＋ Testimoni” pada hasil unduhannya.", "Make an image in Watermark Studio, then press “＋ Testimonial” on the result.")}</p>
        {A.testi.length ? (
          <div className="reviews-strip">
            {A.testi.map((t) => (
              <div key={t.id} className="review-shot" style={{ cursor: "default" }}>
                <img src={t.src} alt={L("Testimoni pelanggan", "Customer review")} loading="lazy" />
                <button type="button" className="btn btn-danger btn-ico x" style={{ background: "var(--card)" }} aria-label="Delete" onClick={() => A.delTesti(t.id)}>✕</button>
              </div>
            ))}
          </div>
        ) : <p className="muted">{L("Belum ada screenshot.", "No screenshots yet.")}</p>}
      </section>

      <section className="stack">
        <h3>{L("Testimoni teks dari pelanggan", "Text testimonials from customers")}</h3>
        {!enabled && <div className="warnbox">{L("Tabel testimoni belum ada di database. Jalankan file drizzle/migrations/0001_testimonials.sql agar pelanggan bisa mengirim testimoni teks.", "The testimonials table is not in the database yet. Run drizzle/migrations/0001_testimonials.sql so customers can send text testimonials.")}</div>}
        {enabled && rows && !rows.length && <p className="muted">{L("Belum ada testimoni teks.", "No text testimonials yet.")}</p>}
        {(rows || []).map((row) => (
          <article className="testimonial" key={row.id}>
            <strong>{row.name} · {row.approved ? L("Ditampilkan", "Shown") : L("Menunggu persetujuan", "Waiting for approval")}</strong>
            <p>{row.message}</p>
            <button type="button" className="btn btn-star btn-sm" onClick={() => toggle(row)}>{row.approved ? L("Sembunyikan", "Hide") : L("Setujui", "Approve")}</button>{" "}
            <button type="button" className="btn btn-danger btn-sm" onClick={() => remove(row)}>{sure === row.id ? L("Yakin?", "Sure?") : L("Hapus", "Delete")}</button>
          </article>
        ))}
        <p role="status">{status}</p>
      </section>
    </div>
  );
}
