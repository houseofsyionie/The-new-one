import { createFileRoute } from "@tanstack/react-router";
import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";

const GATEWAY_URL = "https://connector-gateway.lovable.dev/resend";

const esc = (s: unknown) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!,
  );

// Target date = today in Asia/Jakarta + 3 days.
export function reminderTargetDate(nowMs: number): string {
  const d = new Date(nowMs + 7 * 3600 * 1000);
  d.setUTCDate(d.getUTCDate() + 3);
  return d.toISOString().slice(0, 10);
}

export const Route = createFileRoute("/api/public/jobs/expiry-reminder")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const authFailure = await authenticateCronRequest(request);
        if (authFailure) return authFailure;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const target = reminderTargetDate(Date.now());

        const { data: rows, error } = await supabaseAdmin
          .from("orders")
          .select("id,data,expires_at")
          .eq("expires_at", target)
          .gt("duration_days", 31)
          .eq("remind_sent", false);
        if (error) return new Response("query failed", { status: 500 });
        if (!rows || rows.length === 0) return new Response("nothing to send");

        const { data: cfg } = await supabaseAdmin.from("admin_kv").select("value").eq("key", "reminder").maybeSingle();
        const settings = (cfg?.value ?? {}) as { to?: string; from?: string };
        if (!settings.to) return new Response("no recipient configured", { status: 200 });

        const lovableKey = process.env["LOVABLE_API_KEY"];
        const resendKey = process.env["RESEND_API_KEY"];
        if (!lovableKey || !resendKey) return new Response("email not configured", { status: 500 });

        const list = rows
          .map((r) => {
            const o = r.data as { app?: unknown; type?: unknown; buyer?: unknown; wa?: unknown; renewal?: unknown };
            return `<li><b>${esc(o.app)}</b> (${esc(o.type)}) &middot; buyer ${esc(o.buyer)} &middot; WA ${esc(o.wa)} &middot; ends ${esc(r.expires_at)}${o.renewal ? " &middot; renewal ON" : ""}</li>`;
          })
          .join("");

        const res = await fetch(`${GATEWAY_URL}/emails`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${lovableKey}`,
            "X-Connection-Api-Key": resendKey,
          },
          body: JSON.stringify({
            from: settings.from || "House of Syion <onboarding@resend.dev>",
            to: [settings.to],
            subject: `🎀 ${rows.length} subscription(s) end on ${target}`,
            html: `<p>These subscriptions expire in 3 days:</p><ul>${list}</ul>`,
          }),
        });
        if (!res.ok) {
          const body = await res.text();
          console.error(`Resend failed [${res.status}]: ${body}`);
          return new Response(`email failed [${res.status}]`, { status: 502 });
        }

        await supabaseAdmin
          .from("orders")
          .update({ remind_sent: true })
          .in(
            "id",
            rows.map((r) => r.id),
          );
        return new Response(`sent ${rows.length}`);
      },
    },
  },
});
