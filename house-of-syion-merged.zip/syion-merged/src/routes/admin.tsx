import { createFileRoute, ClientOnly } from '@tanstack/react-router';
import { lazy, Suspense } from 'react';
import { StoreShell } from '@/components/StoreShell';
import { storeOptions } from '@/lib/store';
import { pageHead } from '@/lib/metadata';

// The admin tools use canvas, clipboard and the signed-in session, so they render in the browser only.
const AdminApp = lazy(() => import('@/syion/admin'));

export const Route = createFileRoute('/admin')({
  loader: ({ context }) => context.queryClient.ensureQueryData(storeOptions),
  head: () => {
    const head = pageHead('Admin toko', 'Pengelolaan katalog, pesanan, watermark dan template khusus pemilik House of Syion.');
    return { meta: [...head.meta, { name: 'robots', content: 'noindex' }] };
  },
  component: Admin,
});

function Admin() {
  return (
    <StoreShell>
      <div className="page-heading">
        <p className="eyebrow">OWNER’S LITTLE WORKSPACE</p>
        <h1 className="font-display">Admin tools</h1>
      </div>
      <ClientOnly fallback={null}>
        <Suspense fallback={null}>
          <AdminApp />
        </Suspense>
      </ClientOnly>
    </StoreShell>
  );
}
