// @ts-nocheck
/* eslint-disable */
/* House of Syion shared helpers for the admin tools (ported verbatim from the original single-file app). */
import { createElement as h, useState, useEffect, useRef, useMemo, useContext, createContext, Fragment } from "react";
import { supabase } from "@/integrations/supabase/client";
import { calculateExpiry, orderState } from "./order-state";

/* Same as the original proxy: plain elements, but <button> defaults to type="button" so buttons inside forms never submit by accident. */
export const $=new Proxy({},{get:(_,t)=>(p,...c)=>{const props=p&&p.constructor===Object&&!p.$$typeof;return t==='button'?h('button',{type:'button',...(props?p:{})},...(props?c:[p,...c])):props?h(t,p,...c):h(t,null,p,...c)}});
export { h };
/* ================= core helpers ================= */
export const AppCtx=createContext(null);
export const useApp=()=>useContext(AppCtx);
export const uid=()=>Math.random().toString(36).slice(2,10)+Date.now().toString(36).slice(-4);
export const LS={
  get(k,d){try{const v=localStorage.getItem('syion:'+k);return v==null?d:JSON.parse(v)}catch(e){return d}},
  set(k,v){try{localStorage.setItem('syion:'+k,JSON.stringify(v));return true}catch(e){return false}}
};

/* dates & durations */
export const pad=n=>String(n).padStart(2,'0');
export const isoDate=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
export const today=()=>isoDate(new Date());
export const parseISO=s=>{const a=String(s).split('-').map(Number);return new Date(a[0],a[1]-1,a[2])};
export const addDays=(d,n)=>{const r=new Date(d);r.setDate(r.getDate()+n);return r};
export const addMonths=(d,n)=>{const r=new Date(d.getFullYear(),d.getMonth()+n,1);const last=new Date(r.getFullYear(),r.getMonth()+1,0).getDate();r.setDate(Math.min(d.getDate(),last));return r};
export const diffDays=(a,b)=>Math.round((b-a)/864e5);
export const DUR_OPTS=['1d','2d','3d','4d','5d','1w','2w','1m','2m','3m','4m','5m','6m','1y','custom'];
export const UNIT={d:['hari','day'],w:['minggu','week'],m:['bulan','month'],y:['tahun','year']};
export const cap=s=>s.charAt(0).toUpperCase()+s.slice(1);
export const parseDur=o=>{
  if(o.dur==='custom')return{n:Math.max(1,+o.durN||1),u:o.durU||'d'};
  const m=/^(\d+)([dwmy])$/.exec(o.dur||'1m');
  return m?{n:+m[1],u:m[2]}:{n:1,u:'m'};
};
export const unitLabel=(u,n,lang)=>lang==='id'?UNIT[u][0]:UNIT[u][1]+(n>1?'s':'');
export const durLabel=(o,lang)=>{const d=Number(o.customDays)>0?{n:Number(o.customDays),u:'d'}:parseDur(o);return d.n+' '+cap(unitLabel(d.u,d.n,lang))};
export const prodDur=(s,lang)=>/^\d+[dwmy]$/i.test(s)?durLabel({dur:s.toLowerCase()},lang):s;
export const calcExpiry=calculateExpiry;
export const loc=lang=>lang==='id'?'id-ID':'en-GB';
export const fmtDate=(s,lang)=>s?parseISO(s).toLocaleDateString(loc(lang),{day:'numeric',month:'short',year:'numeric'}):'-';
export const monthLabel=(ym,lang)=>{const a=ym.split('-').map(Number);return new Date(a[0],a[1]-1,1).toLocaleDateString(loc(lang),{month:'long',year:'numeric'})};
export const rp=n=>'Rp '+(Number(n)||0).toLocaleString('id-ID');
export const waDigits=s=>{let d=String(s||'').replace(/\D/g,'');if(d.startsWith('0'))d='62'+d.slice(1);return d};
export const waUrl=(num,text)=>'https://wa.me/'+waDigits(num)+(text?'?text='+encodeURIComponent(text):'');

/* clipboard / images */
export async function copyText(s){
  try{await navigator.clipboard.writeText(s);return true}catch(e){
    try{const ta=document.createElement('textarea');ta.value=s;ta.setAttribute('readonly','');ta.style.cssText='position:fixed;top:0;left:0;opacity:0';document.body.appendChild(ta);ta.select();const ok=document.execCommand('copy');ta.remove();return ok}catch(e2){return false}
  }
}
export const loadImg=src=>new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=src});
export const fileURL=f=>URL.createObjectURL(f);
export async function shrink(src,max,q,transparent=false){
  const i=await loadImg(src),s=Math.min(1,max/Math.max(i.naturalWidth,i.naturalHeight));
  const c=document.createElement('canvas');c.width=Math.round(i.naturalWidth*s);c.height=Math.round(i.naturalHeight*s);
  c.getContext('2d').drawImage(i,0,0,c.width,c.height);return c.toDataURL(transparent?'image/png':'image/jpeg',q);
}
export const ensureFonts=()=>Promise.all(['700 40px "Baloo 2"','40px Chewy','700 40px Quicksand','40px Sniglet'].map(f=>document.fonts.load(f))).catch(()=>{});

/* toast */
export const toastBus=new EventTarget();
export const toast=m=>toastBus.dispatchEvent(new CustomEvent('t',{detail:m}));
/* ================= data layer: Lovable Cloud ================= */
export const ok=r=>{if(r.error)throw r.error;return r.data};
export const DB={
  async list(col){
    const rows=ok(await supabase.from(col).select('id,data').order('created_at',{ascending:true}));
    return(rows||[]).map(r=>Object.assign({},r.data,{id:r.id}));
  },
  async put(col,item){
    const row={id:item.id,data:item};
    if(col==='orders'){row.order_date=item.date||null;row.expires_at=item.expires||null;row.duration_days=item.durDays||0}
    ok(await supabase.from(col).upsert(row));
  },
  async del(col,id){ok(await supabase.from(col).delete().eq('id',id))},
  async getKV(){const rows=ok(await supabase.from('kv').select('key,value')),o={};(rows||[]).forEach(r=>{o[r.key]=r.value});return o},
  async setKV(key,value){ok(await supabase.from('kv').upsert({key,value,updated_at:new Date().toISOString()}))},
  async getAdminKV(){const rows=ok(await supabase.from('admin_kv').select('key,value')),o={};(rows||[]).forEach(r=>{o[r.key]=r.value});return o},
  async setAdminKV(key,value){ok(await supabase.from('admin_kv').upsert({key,value,updated_at:new Date().toISOString()}))}
};
export async function isAdminUser(user){
  if(!user)return false;
  const {data,error}=await supabase.rpc('has_role',{_user_id:user.id,_role:'admin'});
  return !error&&!!data;
}
/* returns 'ok' | 'wrong' | 'unconfirmed' | 'notadmin' */
export async function adminLogin(email,pin){
  const {data,error}=await supabase.auth.signInWithPassword({email:email.trim(),password:pin});
  if(error)return /confirm/i.test(error.message)?'unconfirmed':'wrong';
  if(!(await isAdminUser(data.user))){await supabase.auth.signOut();return 'notadmin'}
  return 'ok';
}
export async function changePin(pin){const {error}=await supabase.auth.updateUser({password:pin});return !error}
export const MIN_PIN=6;


export const KAO=['૮ ˶ᵔ ᵕ ᵔ˶ ა','₍ᐢ. .ᐢ₎','(๑>ᴗ<๑)','⸜(｡˃ ᵕ ˂ )⸝♡','(˶ᵔ ᵕ ᵔ˶)','ฅ^•ﻌ•^ฅ','˚₊‧꒰ა ☆ ໒꒱ ‧₊˚','⋆｡°✩','✧･ﾟ: *✧･ﾟ:*','♡','ദ്ദി(˵ •̀ ᴗ - ˵ ) ✧','₊˚⊹'];
export const TAGS=['#zonauang','#houseofsyion','#readystock','#promo','#appspremium'];

export function ToastHost(){
  const [m,setM]=useState(null);
  useEffect(()=>{
    let tm;const f=e=>{setM({t:e.detail,k:Date.now()});clearTimeout(tm);tm=setTimeout(()=>setM(null),2300)};
    toastBus.addEventListener('t',f);return()=>{toastBus.removeEventListener('t',f);clearTimeout(tm)};
  },[]);
  return m?$.div({className:'toast',role:'status',key:m.k},'✨ '+m.t):null;
}
export function Modal({title,onClose,wide,children}){
  useEffect(()=>{const f=e=>{if(e.key==='Escape')onClose()};addEventListener('keydown',f);return()=>removeEventListener('keydown',f)},[]);
  return $.div({className:'mback',onMouseDown:e=>{if(e.target===e.currentTarget)onClose()}},
    $.div({className:'modal'+(wide?' wide':''),role:'dialog','aria-modal':'true','aria-label':title},
      $.div({className:'modal-h'},$.h3(title),$.button({className:'btn btn-ghost btn-sm',onClick:onClose,'aria-label':'Close'},'✕')),
      $.div({className:'modal-b'},children)));
}
export const Switch=({on,set,label,id})=>$.label({className:'sw'},$.input({type:'checkbox',id,checked:!!on,onChange:e=>set(e.target.checked)}),$.span({className:'sw-t'}),label?$.span(label):null);
export const Field=({label,children,full,plain})=>h(plain?'div':'label',{className:'field'+(full?' full':'')},$.span(label),children);

/* shows plain text that could not be copied automatically */
export function TextModal({text,onClose}){
  const {L}=useApp();const ref=useRef();
  useEffect(()=>{ref.current&&ref.current.select()},[]);
  return h(Modal,{title:L('Salin manual','Copy manually'),onClose},
    $.p({className:'muted',style:{marginBottom:8}},L('Browser menolak akses clipboard. Teks sudah terpilih, tekan Ctrl/Cmd+C.','Your browser blocked clipboard access. The text is selected, press Ctrl/Cmd+C.')),
    $.textarea({ref,readOnly:true,value:text,style:{minHeight:220},id:'manual-copy'}));
}
/* shows rendered images (receipt, watermark results) */
export function ImageModal({results,onClose,title}){
  const A=useApp(),L=A.L;
  return h(Modal,{title:title||L('Hasil','Result'),onClose,wide:true},
    $.p({className:'muted',style:{marginBottom:12}},L('Jika tombol Simpan tidak berjalan, tekan lama (HP) atau klik kanan (komputer) pada gambar lalu simpan.','If Save does nothing, long-press (phone) or right-click (desktop) the image and save it.')),
    $.div({className:'stack'},results.map((r,i)=>$.div({key:i,className:'stack',style:{alignItems:'center'}},
      $.img({src:r.url,alt:r.name,style:{maxHeight:'70vh',borderRadius:14,border:'2px solid var(--glass-brd)'}}),
      $.div({className:'row'},
        $.a({className:'btn btn-star',href:r.url,download:r.name},'⬇ '+L('Simpan','Save')),
        r.testi?$.button({className:'btn btn-pink',onClick:async()=>{try{await A.addTesti(await shrink(r.url,900,.82));toast(L('Masuk ke testimoni','Added to testimonials'))}catch(e){toast(L('Gagal menambah','Could not add'))}}},'＋ '+L('Testimoni','Testimonial')):null)))));
}
