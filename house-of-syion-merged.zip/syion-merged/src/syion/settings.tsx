// @ts-nocheck
/* eslint-disable */
import { useState } from "react";
import { AppCtx, Field, MIN_PIN, toast, useApp } from "./shared";
import { IntegrationSettings } from "./integration-settings";

/* Settings: profile for the storefront, admin PIN, reminder and Sheets integration. Products now live in the Catalog tab. */
export function Settings() {
  const A = useApp(), L = A.L, P = A.profile;
  const [f, setF] = useState({ bio: P.bio || "", wa: P.wa || "", greeting: P.greeting || "", nick: P.nick || "", x: P.x || "" });
  const [pin, setPin] = useState(""), [pin2, setPin2] = useState("");
  const saveProfile = async (e) => {
    e.preventDefault();
    if (await A.setProfile({ ...P, ...f })) toast(L("Profil tersimpan", "Profile saved"));
  };
  const changePin = async (e) => {
    e.preventDefault();
    if (pin.length < MIN_PIN) { toast(L("PIN minimal " + MIN_PIN + " angka", "PIN needs at least " + MIN_PIN + " digits")); return; }
    if (pin !== pin2) { toast(L("Konfirmasi PIN tidak sama", "PINs do not match")); return; }
    if (await A.changePin(pin)) { toast(L("PIN diganti", "PIN changed")); setPin(""); setPin2(""); }
    else toast(L("Gagal mengganti PIN", "Could not change the PIN"));
  };
  return (
    <div className="stack">
      <h2 className="sec-title">{L("Pengaturan", "Settings")}<small>✧ Lovable Cloud</small></h2>
      <form className="glass pad stack" onSubmit={saveProfile}>
        <h3>{L("Profil toko", "Shop profile")}</h3>
        <div className="form-grid">
          <Field label={L("No. WhatsApp toko", "Shop WhatsApp")}><input id="s-wa" type="tel" placeholder="08xxxxxxxxxx" value={f.wa} onChange={(e) => setF({ ...f, wa: e.target.value })} /></Field>
          <Field label={L("Akun X (tanpa @)", "X account (without @)")}><input id="s-x" type="text" placeholder="molenkul" value={f.x} onChange={(e) => setF({ ...f, x: e.target.value })} /></Field>
          <Field label={L("Nama di kartu profil", "Name on the profile card")}><input id="s-nick" type="text" placeholder="syion-ie 🔮" value={f.nick} onChange={(e) => setF({ ...f, nick: e.target.value })} /></Field>
          <Field label="Bio" full><input id="s-bio" type="text" value={f.bio} onChange={(e) => setF({ ...f, bio: e.target.value })} /></Field>
          <Field label={L("Pesan sapaan WhatsApp", "WhatsApp greeting")} full><input id="s-greet" type="text" value={f.greeting} onChange={(e) => setF({ ...f, greeting: e.target.value })} /></Field>
        </div>
        <p className="muted">{L("Banner & foto profil diganti lewat tombol ✎ di halaman Katalog. Nama toko, URL banner dan tema ada di tab Katalog & harga.", "Change the banner and profile picture with the ✎ buttons on the Catalog page. Store name, banner URL and theme are in the Catalog & prices tab.")}</p>
        <div className="row"><button className="btn btn-star" type="submit">💾 {L("Simpan", "Save")}</button></div>
      </form>
      <form className="glass pad stack" onSubmit={changePin}>
        <h3>{L("Ganti PIN admin", "Change admin PIN")}</h3>
        <div className="form-grid">
          <Field label={L("PIN baru", "New PIN")}><input id="pin-new" type="password" inputMode="numeric" autoComplete="new-password" value={pin} onChange={(e) => setPin(e.target.value)} /></Field>
          <Field label={L("Ulangi PIN", "Repeat PIN")}><input id="pin-new2" type="password" inputMode="numeric" autoComplete="new-password" value={pin2} onChange={(e) => setPin2(e.target.value)} /></Field>
        </div>
        <div className="row"><button className="btn btn-pink" type="submit">{L("Ganti PIN", "Change PIN")}</button></div>
      </form>
      <IntegrationSettings />
    </div>
  );
}
