import { queryOptions, useSuspenseQuery } from '@tanstack/react-query';
import { useMemo } from 'react';
import { readStore } from './store.functions';
import { buildStore, type Store } from './store-model';

export * from './store-model';

export const storeOptions = queryOptions({ queryKey: ['store'], queryFn: () => readStore(), staleTime: 30000 });

/** Normalized storefront data: catalog (prices), profile and review images. */
export function useStore(): Store {
  const raw = useSuspenseQuery(storeOptions).data;
  return useMemo(() => buildStore(raw), [raw]);
}
