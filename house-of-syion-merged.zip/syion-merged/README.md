# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

---

## Menjalankan di luar Lovable

1. Pasang dependensi: `bun install` (atau `npm install`).
2. Jalankan: `bun run dev`.
3. Skema database ada di `drizzle/migrations/0000_migration.sql` (jalankan pada database
   baru) dan `0001_testimonials.sql` (WAJIB dijalankan di database yang sudah ada untuk
   testimoni teks; tidak mengubah data lama) agar tabel `kv`, `orders`, `templates`, `admin_kv`, dan
   `user_roles` beserta aturannya tersedia.
4. Berkas `.env` berisi alamat dan kunci publik backend saat ini. Bila pindah ke
   backend lain, ganti isinya dengan milikmu sendiri.
5. Job pengingat kedaluwarsa ada di `src/routes/api/public/jobs/expiry-reminder.ts`
   dan memerlukan variabel lingkungan `LOVABLE_CRON_SECRET`, `RESEND_API_KEY`,
   serta `LOVABLE_API_KEY` di sisi server.
6. Font `src/assets/Blueberry.ttf` disertakan. Aturan `@font-face` di
   `src/styles.css` masih menunjuk ke alamat aset Lovable. Bila di-hosting di
   tempat lain, salin font ke `public/fonts/Blueberry.ttf` lalu ubah baris
   `@font-face` menjadi `src:url('/fonts/Blueberry.ttf') format('truetype')`.
   Font ini berlisensi *personal use only* — butuh lisensi komersial untuk
   penggunaan pada toko komersial.
