import { useEffect, useRef } from 'react';

export const WELCOME_TEXT = `⋆ ˚｡⋆୨୧˚ Welcome to Our Store! ˚୨୧⋆｡˚ ⋆
Halo Kak! Selamat datang ૮ ˶ᵔ ᵕ ᵔ˶ ა
Terima kasih sudah mampir. Kami menyediakan berbagai kebutuhan akun premium yang aman, cepat, dan terpercaya! ☁️✨
꒰ ⚠️ ꒱ RULES SEBELUM MEMBELI ꒰ ⚠️ ꒱
Mohon dibaca sebentar ya Kak sebelum order:
♡ 1. Pastikan aplikasi atau layanan yang ingin dipesan sudah benar dan sesuai kebutuhanmu (jika yang dicari tidak ada dalam daftar bisa langsung tanyakan ke Admin ya!).
♡ 2. Proses pengerjaan biasanya 1 - 30 menit (tergantung antrean). Mohon bersabar menunggu yaa ( ˘͈ ᵕ ˘͈♡)
♡ 3. Sistem kita Pay First (Pembayaran lunas di awal) baru pesanan akan diproses 💸
♡ 4. Garansi berlaku sesuai S&K. Pastikan tidak melanggar aturan penggunaan akun agar garansi tetap aman 🎀
♡ 5. Strictly No Refund (Tidak ada pengembalian dana) jika terjadi kesalahan order dari pihak pembeli ❌
꒰ 🛒 ꒱ CARA PEMESANAN ꒰ 🛒 ꒱
Gimana cara ordernya? Gampang banget!
♡ 1. Pilih produk/layanan yang kamu inginkan.
♡ 2. Klik tombol "Pesan Sekarang" atau langsung klik link untuk chat Admin 💌
♡ 3. Lakukan pembayaran sesuai instruksi dan jangan lupa kirimkan bukti transfer.
♡ 4. Duduk manis, pesananmu akan segera kami proses! ૮ ˶ˆ ﻌ ˆ˶ ა
Happy Shopping & Enjoy your premium vibes! ✨`;

export function Welcome({ onClose }: { onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    ref.current?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab') { e.preventDefault(); ref.current?.querySelector<HTMLButtonElement>('button')?.focus(); }
    };
    window.addEventListener('keydown', key);
    return () => { document.body.style.overflow = overflow; window.removeEventListener('keydown', key); if (previous instanceof HTMLElement) previous.focus(); };
  }, [onClose]);
  return <div className="mback welcome-back"><div ref={ref} tabIndex={-1} className="welcome-modal" role="dialog" aria-modal="true" aria-label="Welcome to Our Store!">
    <div className="welcome-copy">{WELCOME_TEXT.split('\n').map((line, index) => index === 0 ? <h2 key={index}>{line}</h2> : line.startsWith('꒰') ? <h3 key={index}>{line}</h3> : <p key={index}>{line}</p>)}</div>
    <button type="button" className="btn btn-star welcome-close" onClick={onClose}>Mengerti 🎀</button>
  </div></div>;
}