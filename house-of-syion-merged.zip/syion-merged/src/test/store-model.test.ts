import { describe, expect, it } from "vitest";
import { buildOrderText, buildStore, waLink } from "@/lib/store-model";
import { catalogSchema } from "@/lib/catalog-schema";

describe("store model", () => {
  it("falls back to the default price list", () => {
    const s = buildStore({});
    expect(s.saved).toBe(false);
    expect(s.catalog.apps.length).toBeGreaterThan(20);
  });
  it("keeps legacy custom products without deleting data", () => {
    const s = buildStore({ custom_products: [{ id: "c1", name: "Produk Lama", cat: "Custom", durs: ["1m", "3d"] }] });
    const a = s.catalog.apps.find((x) => x.name === "Produk Lama");
    expect(a?.variants.map((v) => v.duration)).toEqual(["1 Bulan", "3 Hari"]);
  });
  it("prefers a saved catalog", () => {
    const base = buildStore({}).catalog;
    expect(buildStore({ catalog: base }).saved).toBe(true);
  });
  it("rejects a negative price", () => {
    const base = structuredClone(buildStore({}).catalog);
    base.apps[0]!.variants[0]!.price = -1;
    expect(catalogSchema.safeParse(base).success).toBe(false);
  });
  it("formats order text and wa links", () => {
    expect(buildOrderText({ app: "Netflix", type: "Sharing", duration: "1 Hari", price: 6000 })).toContain("Rp 6.000");
    expect(waLink({ wa: "0851" }, "hi")).toBe("https://wa.me/62851?text=hi");
  });
});
