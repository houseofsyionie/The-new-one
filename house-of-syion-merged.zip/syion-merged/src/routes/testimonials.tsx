import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { StoreShell } from '@/components/StoreShell';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { testimonialSchema } from '@/lib/catalog-schema';
import { storeOptions, useStore } from '@/lib/store';
import { usePrefs } from '@/lib/prefs';
import { pageHead } from '@/lib/metadata';
import { Modal } from '@/syion/shared';

export const Route = createFileRoute('/testimonials')({
  loader: ({ context }) => context.queryClient.ensureQueryData(storeOptions),
  head: () => pageHead('Testimonials', 'Pengalaman pelanggan House of Syion. Kirim testimoni teks tanpa perlu login.'),
  component: Testimonials,
});

type Row = { id: string; name: string; message: string };

function Testimonials() {
  const { images } = useStore();
  const { t } = usePrefs();
  const [rows, setRows] = useState<Row[]>([]);
  const [enabled, setEnabled] = useState(true);
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);
  const [shot, setShot] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .from('testimonials')
      .select('id,name,message')
      .eq('approved', true)
      .order('created_at', { ascending: false })
      .then(({ data, error }) => {
        if (error) setEnabled(false);
        else setRows(data ?? []);
      });
  }, []);

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const values = new FormData(form);
    const parsed = testimonialSchema.safeParse({ name: values.get('name'), message: values.get('message') });
    if (!parsed.success) {
      setStatus(t('Isi nama dan testimoni minimal 5 karakter.', 'Enter your name and at least 5 characters of feedback.'));
      return;
    }
    setBusy(true);
    const { error } = await supabase.from('testimonials').insert({ ...parsed.data, approved: false });
    setStatus(
      error
        ? t('Testimoni gagal dikirim. Coba lagi.', 'Could not send your testimonial. Please try again.')
        : t('Terima kasih! Testimoni dikirim dan menunggu persetujuan pemilik.', 'Thank you! Your testimonial is waiting for the owner’s approval.'),
    );
    setBusy(false);
    if (!error) form.reset();
  };

  return (
    <StoreShell>
      <div className="page-heading">
        <p className="eyebrow">KIND WORDS, LITTLE STARS</p>
        <h1 className="font-display">{t('Testimoni', 'Testimonials')}</h1>
      </div>

      {images.length > 0 && (
        <section>
          <p className="eyebrow">{t('SCREENSHOT PELANGGAN', 'CUSTOMER SCREENSHOTS')}</p>
          <div className="reviews-strip" tabIndex={0} aria-label={t('Screenshot testimoni', 'Review screenshots')}>
            {images.map((im) => (
              <button key={im.id} type="button" className="review-shot" onClick={() => setShot(im.src)} aria-label={t('Perbesar testimoni', 'Enlarge review')}>
                <img src={im.src} alt={t('Testimoni pelanggan', 'Customer review')} loading="lazy" />
              </button>
            ))}
          </div>
        </section>
      )}

      <div className="testimonial-list">
        {rows.map((r) => (
          <article className="testimonial" key={r.id}>
            <p>“{r.message}”</p>
            <strong>— {r.name}</strong>
          </article>
        ))}
        {!rows.length && !images.length && <p className="text-muted-foreground">{t('Belum ada testimoni yang ditampilkan.', 'No testimonials to show yet.')}</p>}
      </div>

      {enabled ? (
        <form className="order-form" onSubmit={submit}>
          <h2 className="font-display">Leave a little love ✧</h2>
          <label>
            {t('Nama', 'Name')}
            <input name="name" maxLength={80} required placeholder={t('Nama kamu', 'Your name')} />
          </label>
          <label>
            {t('Testimoni', 'Testimonial')}
            <textarea name="message" minLength={5} maxLength={1500} required placeholder={t('Ceritakan pengalamanmu...', 'Tell us about your experience...')} rows={4} />
          </label>
          <Button disabled={busy} type="submit">
            {busy ? t('Mengirim...', 'Sending...') : t('Kirim testimoni', 'Send testimonial')}
          </Button>
          <p role="status">{status}</p>
        </form>
      ) : (
        <p className="page-note">{t('Kiriman testimoni teks belum diaktifkan.', 'Text testimonials are not switched on yet.')}</p>
      )}

      {shot && (
        <Modal title={t('Testimoni', 'Review')} wide onClose={() => setShot(null)}>
          <img src={shot} alt={t('Testimoni pelanggan', 'Customer review')} style={{ maxHeight: '75vh', margin: '0 auto', borderRadius: 6 }} />
        </Modal>
      )}
    </StoreShell>
  );
}
