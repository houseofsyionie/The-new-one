import { describe, expect, it } from "vitest";
import { reminderTargetDate } from "@/routes/api/public/jobs/expiry-reminder";

describe("expiry reminder date", () => {
  it("targets 3 days after today in Jakarta time", () => {
    // 02:00 UTC on 27 Oct = 09:00 WIB on 27 Oct -> 30 Oct
    expect(reminderTargetDate(Date.UTC(2026, 9, 27, 2, 0))).toBe("2026-10-30");
  });
  it("uses the Jakarta date even when UTC is still the previous day", () => {
    // 20:00 UTC on 27 Oct = 03:00 WIB on 28 Oct -> 31 Oct
    expect(reminderTargetDate(Date.UTC(2026, 9, 27, 20, 0))).toBe("2026-10-31");
  });
});
