-- Text testimonials sent by customers from /testimonials. Existing tables and data are untouched.
create table if not exists public.testimonials (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 60),
  message text not null check (char_length(message) between 1 and 500),
  approved boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.testimonials enable row level security;
create policy "testimonials public read approved" on public.testimonials for select to anon, authenticated using (approved = true);
create policy "testimonials public insert pending" on public.testimonials for insert to anon, authenticated with check (approved = false);
create policy "testimonials admin all" on public.testimonials for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
