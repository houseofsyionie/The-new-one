import { createFileRoute, Link } from '@tanstack/react-router';
import { useState } from 'react';
import { StoreShell } from '@/components/StoreShell';
import { Button } from '@/components/ui/button';
import { storeOptions, useStore, rupiah, waLink, buildOrderText } from '@/lib/store';
import { usePrefs } from '@/lib/prefs';
import { pageHead } from '@/lib/metadata';

export const Route = createFileRoute('/order/$appId')({
  loader: ({ context }) => context.queryClient.ensureQueryData(storeOptions),
  head: () => pageHead('Order aplikasi', 'Pilih tipe akun dan durasi aplikasi premium, lalu pesan via WhatsApp.'),
  component: Order,
});

function Order() {
  const { appId } = Route.useParams();
  const { catalog, profile } = useStore();
  const { t } = usePrefs();
  const app = catalog.apps.find((a) => a.id === appId);
  const [selected, setSelected] = useState(0);
  const variant = app?.variants[selected] ?? app?.variants[0];

  return (
    <StoreShell>
      <Button asChild variant="ghost">
        <Link to="/">← {t('Katalog', 'Catalog')}</Link>
      </Button>
      <div className="page-heading">
        <p className="eyebrow">YOUR EVERYDAY MAGIC</p>
        <h1 className="font-display">{app?.name ?? t('Aplikasi tidak ditemukan', 'App not found')}</h1>
      </div>
      {app && variant && (
        <div className="order-form">
          {app.note && <p>{app.note}</p>}
          <label>
            {t('Jenis / tipe akun', 'Account type')}
            <select value={variant.type} onChange={(e) => setSelected(Math.max(0, app.variants.findIndex((v) => v.type === e.target.value)))}>
              {[...new Set(app.variants.map((v) => v.type))].map((ty) => (
                <option key={ty}>{ty}</option>
              ))}
            </select>
          </label>
          <label>
            {t('Durasi', 'Duration')}
            <select value={app.variants.indexOf(variant)} onChange={(e) => setSelected(Number(e.target.value))}>
              {app.variants.map((v, i) =>
                v.type === variant.type ? (
                  <option key={i} value={i}>
                    {v.duration} — {v.price > 0 ? `Rp ${rupiah(v.price)}` : t('tanya admin', 'ask admin')}
                  </option>
                ) : null,
              )}
            </select>
          </label>
          <div className="order-total">
            <small>Total</small>
            <strong>{variant.price > 0 ? `Rp ${rupiah(variant.price)}` : t('Tanya admin', 'Ask admin')}</strong>
          </div>
          {app.active ? (
            <Button asChild>
              <a href={waLink(profile, buildOrderText({ app: app.name, ...variant }))} target="_blank" rel="noreferrer">
                {t('Pesan via WhatsApp', 'Order via WhatsApp')} ↗
              </a>
            </Button>
          ) : (
            <Button disabled>{t('Tutup', 'Closed')}</Button>
          )}
        </div>
      )}
    </StoreShell>
  );
}
