import { defaultCatalog, type AppItem, type Catalog, type OrderField } from '@/data/catalog';
import { catalogSchema } from '@/lib/catalog-schema';

/*
 * Public storefront data lives in the anon-readable `kv` table.
 *   catalog          new price catalog (apps, variants, prices, settings)  <- written by the catalog editor
 *   profile          banner, avatar, WhatsApp number, bio, greeting          <- original keys, never deleted
 *   custom_products  original custom products                                <- legacy, read only
 *   catalog_overrides original per-product edits                             <- legacy, read only
 *   testimonials     original watermarked review images                      <- original keys, never deleted
 * Until the owner saves the catalog once, the page shows the new price list merged with the legacy keys.
 */

export type Profile = {
  name: string;
  bio: string;
  wa: string;
  greeting: string;
  banner: string | null;
  avatar: string | null;
  nick: string;
  x: string;
};
export const DEFAULT_PROFILE: Profile = { name: '', bio: '', wa: '', greeting: '', banner: null, avatar: null, nick: '', x: '' };
export const DEFAULT_WA = '6285161214039';
export const DEFAULT_X = 'molenkul';
export const DEFAULT_NICK = 'syion-ie 🔮';

export type ImageReview = { id: string; src: string };
export type RawStore = Record<string, unknown>;
export type Store = { catalog: Catalog; profile: Profile; images: ImageReview[]; saved: boolean };
export const STORE_KEYS = ['catalog', 'profile', 'custom_products', 'catalog_overrides', 'testimonials'] as const;

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);
const str = (v: unknown): string => (typeof v === 'string' ? v : '');
export const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '');

const LEGACY_CATEGORY: Record<string, string> = {
  Entertainment: 'Streaming & Music',
  AI: 'AI & Education',
  Design: 'Design & Editing',
  Custom: 'Other',
};
// Original short names that differ from the new price list names.
const ALIASES: Record<string, string> = { appmus: 'applemusic', ms365: 'microsoft365' };

const DUR_WORD: Record<string, [string, string, string, string]> = { d: ['Hari', '', '', ''], w: ['Minggu', '', '', ''], m: ['Bulan', '', '', ''], y: ['Tahun', '', '', ''] };
export const legacyDuration = (d: string): string => {
  const m = /^(\d+)([dwmy])$/i.exec(d.trim());
  if (!m) return d.trim();
  const w = DUR_WORD[m[2]!.toLowerCase()];
  return `${m[1]} ${w ? w[0] : m[2]}`;
};

const toFields = (v: unknown): OrderField[] | undefined => {
  if (!Array.isArray(v)) return undefined;
  const out: OrderField[] = [];
  for (const f of v) {
    if (!isObj(f) || !str(f['id']) || !str(f['label'])) continue;
    const t = str(f['type']);
    out.push({
      id: str(f['id']),
      label: str(f['label']),
      type: t === 'number' || t === 'date' || t === 'textarea' ? t : 'text',
      required: f['required'] === true,
    });
  }
  return out.length ? out : undefined;
};

const mapCategory = (cat: unknown): string => {
  const c = str(cat).trim();
  return LEGACY_CATEGORY[c] ?? (c || 'Other');
};

function ensureCategory(cat: Catalog, name: string) {
  if (!cat.categories.includes(name)) cat.categories.push(name);
}

function applyLegacy(cat: Catalog, overrides: unknown, custom: unknown) {
  const byKey = new Map<string, AppItem>(cat.apps.map((a) => [norm(a.name), a]));
  const find = (name: string) => {
    const k = norm(name);
    return byKey.get(ALIASES[k] ?? k);
  };
  const merge = (app: AppItem, o: Record<string, unknown>) => {
    const name = str(o['name']).trim();
    if (name) app.name = name;
    const details = str(o['details']).trim();
    if (details && !(app.note ?? '').includes(details)) app.note = [app.note, details].filter(Boolean).join(' · ');
    const fields = toFields(o['fields']);
    if (fields) app.fields = fields;
    if (o['cat'] !== undefined) {
      app.category = mapCategory(o['cat']);
      ensureCategory(cat, app.category);
    }
  };
  const fromLegacy = (o: Record<string, unknown>, fallbackId: string): AppItem | null => {
    const name = str(o['name']).trim();
    if (!name) return null;
    const durs = Array.isArray(o['durs']) ? (o['durs'] as unknown[]).map(str).filter(Boolean) : [];
    const category = mapCategory(o['cat']);
    ensureCategory(cat, category);
    const item: AppItem = {
      id: str(o['id']) || fallbackId,
      name,
      category,
      active: true,
      variants: (durs.length ? durs : ['1m']).map((d) => ({ type: 'Custom', duration: legacyDuration(d), price: 0 })),
    };
    const details = str(o['details']).trim();
    if (details) item.note = details;
    const fields = toFields(o['fields']);
    if (fields) item.fields = fields;
    return item;
  };

  if (isObj(overrides)) {
    for (const [id, o] of Object.entries(overrides)) {
      if (!id.startsWith('b-') || !isObj(o)) continue;
      const app = find(id.slice(2));
      if (app) merge(app, o);
      else {
        const item = fromLegacy({ ...o, id: '' }, 'legacy-' + norm(id));
        if (item) cat.apps.push(item);
      }
    }
  }
  if (Array.isArray(custom)) {
    for (const o of custom) {
      if (!isObj(o)) continue;
      const name = str(o['name']).trim();
      const existing = name ? find(name) : undefined;
      if (existing) {
        merge(existing, o);
        continue;
      }
      const item = fromLegacy(o, 'c-' + norm(name));
      if (item && !cat.apps.some((a) => a.id === item.id)) cat.apps.push(item);
    }
  }
}

export function buildStore(raw: RawStore): Store {
  const profile: Profile = { ...DEFAULT_PROFILE, ...(isObj(raw['profile']) ? (raw['profile'] as Partial<Profile>) : {}) };
  const images: ImageReview[] = Array.isArray(raw['testimonials'])
    ? (raw['testimonials'] as unknown[]).flatMap((t) => (isObj(t) && str(t['id']) && str(t['src']) ? [{ id: str(t['id']), src: str(t['src']) }] : []))
    : [];
  const parsed = catalogSchema.safeParse(raw['catalog']);
  if (parsed.success) return { catalog: parsed.data as Catalog, profile, images, saved: true };
  const catalog = structuredClone(defaultCatalog);
  applyLegacy(catalog, raw['catalog_overrides'], raw['custom_products']);
  return { catalog, profile, images, saved: false };
}

/* ---- helpers shared by pages ---- */
export const rupiah = (n: number) => n.toLocaleString('id-ID');
export const waDigits = (s: string) => {
  const d = String(s || '').replace(/\D/g, '');
  return d.startsWith('0') ? '62' + d.slice(1) : d;
};
export const waNumber = (p: Pick<Profile, 'wa'>) => waDigits(p.wa) || DEFAULT_WA;
export const waDisplay = (p: Pick<Profile, 'wa'>) => {
  const n = waNumber(p);
  return n.startsWith('62') ? '0' + n.slice(2) : n;
};
export const waLink = (p: Pick<Profile, 'wa'>, text?: string) => `https://wa.me/${waNumber(p)}${text ? `?text=${encodeURIComponent(text)}` : ''}`;
export const priceText = (n: number) => (n > 0 ? `Rp ${rupiah(n)}` : 'Tanya admin');
export const lowestPrice = (a: AppItem) => {
  const prices = a.variants.map((v) => v.price).filter((p) => p > 0);
  return prices.length ? Math.min(...prices) : 0;
};
export const buildOrderText = (p: { app: string; type: string; duration: string; price: number }) =>
  `✦ Order Form ✦\n\nProduk : ${p.app}\nJenis : ${p.type}\nDurasi : ${p.duration}\nTotal : ${p.price > 0 ? `Rp ${rupiah(p.price)}` : '(tanya admin)'}`;

/* Product list in the shape the order tools expect. */
export const toolProducts = (c: Catalog) =>
  c.apps.map((a) => ({
    id: a.id,
    name: a.name,
    cat: a.category,
    durs: [...new Set(a.variants.map((v) => v.duration))],
    fields: a.fields ?? [],
  }));
