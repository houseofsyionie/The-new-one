import { z } from 'zod';
const orderField = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  type: z.enum(['text', 'number', 'date', 'textarea']),
  required: z.boolean(),
});
export const catalogSchema = z.object({
  categories: z.array(z.string().min(1)),
  apps: z.array(
    z.object({
      id: z.string().min(1),
      name: z.string().min(1),
      category: z.string().min(1),
      active: z.boolean(),
      note: z.string().optional(),
      icon: z.string().max(16).optional(),
      fields: z.array(orderField).optional(),
      variants: z.array(z.object({ type: z.string().min(1), duration: z.string().min(1), price: z.number().min(0) })).min(1),
    }),
  ),
  settings: z
    .object({
      title: z.string().trim().max(60).optional(),
      bannerUrl: z.union([z.literal(''), z.string().url().startsWith('https://')]).optional(),
      theme: z.enum(['lavender', 'midnight']).optional(),
    })
    .optional(),
});
export const testimonialSchema = z.object({ name: z.string().trim().min(1).max(80), message: z.string().trim().min(5).max(1500) });
