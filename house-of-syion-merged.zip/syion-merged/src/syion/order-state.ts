import { addDays, addMonths, differenceInCalendarDays, format, parseISO } from 'date-fns';

export function calculateExpiry(date: string, order: { dur?: string; durN?: number | string; durU?: string; customDays?: number | string }) {
  const base = parseISO(date);
  const match = /^(\d+)([dwmy])$/.exec(order.dur || '1m');
  const n = order.dur === 'custom' ? Math.max(1, Number(order.durN) || 1) : Number(match?.[1] || 1);
  const unit = order.dur === 'custom' ? order.durU || 'd' : match?.[2] || 'm';
  const override = Number(order.customDays);
  const expires = override > 0 ? addDays(base, Math.floor(override)) : unit === 'd' ? addDays(base, n) : unit === 'w' ? addDays(base, n * 7) : addMonths(base, n * (unit === 'y' ? 12 : 1));
  return { expires: format(expires, 'yyyy-MM-dd'), days: differenceInCalendarDays(expires, base) };
}

export function orderState(order: { date?: string; expires?: string; durDays?: number; hasProof?: boolean; proof?: unknown }, today: string) {
  const remaining = order.expires ? differenceInCalendarDays(parseISO(order.expires), parseISO(today)) : 0;
  const total = order.date && order.expires ? differenceInCalendarDays(parseISO(order.expires), parseISO(order.date)) : order.durDays || 0;
  return {
    remaining: Math.max(0, remaining),
    percentage: total > 0 ? Math.max(0, Math.min(100, Math.round(remaining / total * 100))) : 0,
    status: remaining <= 0 ? 'Expired' : remaining <= 3 ? 'Needs Renewal' : 'Active',
    warranty: order.hasProof === undefined ? Boolean(order.proof) : order.hasProof,
  };
}