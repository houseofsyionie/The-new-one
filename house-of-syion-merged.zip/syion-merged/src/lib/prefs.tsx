import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

export type Lang = 'id' | 'en';
export type Theme = 'light' | 'dark';

// Same storage keys as the original app, so the visitor's saved language and theme carry over.
const read = <T,>(key: string, fallback: T): T => {
  try {
    const v = localStorage.getItem('syion:' + key);
    return v == null ? fallback : (JSON.parse(v) as T);
  } catch {
    return fallback;
  }
};
const write = (key: string, value: unknown) => {
  try {
    localStorage.setItem('syion:' + key, JSON.stringify(value));
  } catch {
    /* private mode or full storage: the choice just lasts for this visit */
  }
};

type Prefs = {
  lang: Lang;
  setLang: (l: Lang) => void;
  theme: Theme | null;
  setTheme: (t: Theme) => void;
  /** pick the Indonesian or English text */
  t: (id: string, en: string) => string;
};

const PrefsCtx = createContext<Prefs | null>(null);

export function PrefsProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>('id');
  const [theme, setThemeState] = useState<Theme | null>(null);

  // Read after hydration so server and browser render the same first frame.
  useEffect(() => {
    const l = read<string>('lang', 'id');
    if (l === 'en' || l === 'id') setLangState(l);
    const th = read<string | null>('theme', null);
    if (th === 'light' || th === 'dark') setThemeState(th);
  }, []);

  const value = useMemo<Prefs>(
    () => ({
      lang,
      setLang: (l) => {
        setLangState(l);
        write('lang', l);
        document.documentElement.lang = l;
      },
      theme,
      setTheme: (t) => {
        setThemeState(t);
        write('theme', t);
      },
      t: (id, en) => (lang === 'id' ? id : en),
    }),
    [lang, theme],
  );
  return <PrefsCtx.Provider value={value}>{children}</PrefsCtx.Provider>;
}

export function usePrefs(): Prefs {
  const v = useContext(PrefsCtx);
  if (!v) throw new Error('usePrefs must be used inside PrefsProvider');
  return v;
}

/** Applies the visitor's choice, or the store's default theme, to <html>. */
export function useApplyTheme(storeDefault: 'lavender' | 'midnight' | undefined): Theme {
  const { theme } = usePrefs();
  const effective: Theme = theme ?? (storeDefault === 'midnight' ? 'dark' : 'light');
  useEffect(() => {
    document.documentElement.classList.toggle('dark', effective === 'dark');
  }, [effective]);
  return effective;
}
