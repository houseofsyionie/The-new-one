// @ts-nocheck
/* eslint-disable */
import { useState, useEffect, useRef, useMemo, useContext, createContext, Fragment } from "react";
import { supabase } from "@/integrations/supabase/client";
import { calculateExpiry, orderState } from "./order-state";
import { $, AppCtx, DB, DUR_OPTS, Field, ImageModal, KAO, LS, MIN_PIN, Modal, Switch, TAGS, TextModal, ToastHost, UNIT, addDays, addMonths, adminLogin, calcExpiry, cap, changePin, copyText, diffDays, durLabel, ensureFonts, fileURL, fmtDate, h, isAdminUser, isoDate, loadImg, loc, monthLabel, ok, pad, parseDur, parseISO, prodDur, rp, shrink, toast, toastBus, today, uid, unitLabel, useApp, waDigits, waUrl } from "./shared";
/* ================= watermark studio ================= */
export const INK='#3B3486';
export const dot=(x,cx,cy,r)=>{x.beginPath();x.arc(cx,cy,r,0,7);x.fill()};
export const rr=(x,a,b,w,hh,q)=>{x.beginPath();x.moveTo(a+q,b);x.arcTo(a+w,b,a+w,b+hh,q);x.arcTo(a+w,b+hh,a,b+hh,q);x.arcTo(a,b+hh,a,b,q);x.arcTo(a,b,a+w,b,q);x.closePath()};
export const face=(x,r,dy)=>{
  x.fillStyle=INK;dot(x,-.16*r,dy,.055*r);dot(x,.16*r,dy,.055*r);
  x.fillStyle='rgba(255,140,175,.8)';dot(x,-.3*r,dy+.1*r,.07*r);dot(x,.3*r,dy+.1*r,.07*r);
  x.strokeStyle=INK;x.lineWidth=r*.04;x.beginPath();x.arc(0,dy+.04*r,.07*r,.15*Math.PI,.85*Math.PI);x.stroke();
};
export const SD={
  cloud:(x,r)=>{const cs=[[-.5,.1,.3],[-.2,-.12,.4],[.22,-.02,.34],[.5,.14,.26],[-.15,.2,.3],[.2,.2,.3]];x.strokeStyle='#A2E1FF';x.lineWidth=r*.16;cs.forEach(c=>{x.beginPath();x.arc(c[0]*r,c[1]*r,c[2]*r,0,7);x.stroke()});x.fillStyle='#fff';cs.forEach(c=>dot(x,c[0]*r,c[1]*r,c[2]*r));face(x,r,.12*r)},
  star:(x,r)=>{x.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,q=i%2?.45:1;x.lineTo(Math.cos(a)*r*.95*q,Math.sin(a)*r*.95*q)}x.closePath();x.fillStyle='#FFF38B';x.strokeStyle='#f2c94c';x.lineWidth=r*.1;x.stroke();x.fill();face(x,r,.05*r)},
  heart:(x,r)=>{x.beginPath();x.moveTo(0,.8*r);x.bezierCurveTo(-1.1*r,.1*r,-.7*r,-.8*r,0,-.35*r);x.bezierCurveTo(.7*r,-.8*r,1.1*r,.1*r,0,.8*r);x.closePath();x.fillStyle='#FFB8D0';x.strokeStyle='#ff8fb8';x.lineWidth=r*.1;x.stroke();x.fill();face(x,r,-.02*r)},
  bandaid:(x,r)=>{x.rotate(-.3);rr(x,-r,-.38*r,2*r,.76*r,.38*r);x.fillStyle='#FFD9C2';x.fill();x.strokeStyle='#f0b79a';x.lineWidth=r*.07;x.stroke();rr(x,-.4*r,-.38*r,.8*r,.76*r,.1*r);x.fillStyle='#FFE9DB';x.fill();x.stroke();x.fillStyle='#f0b79a';[[-.75,-.12],[-.75,.12],[-.6,0],[.75,-.12],[.75,.12],[.6,0]].forEach(p=>dot(x,p[0]*r,p[1]*r,.04*r))},
  moon:(x,r)=>{x.save();x.beginPath();x.rect(-2*r,-2*r,4*r,4*r);x.arc(.38*r,-.12*r,.72*r,0,7,true);x.clip('evenodd');x.beginPath();x.arc(0,0,.9*r,0,7);x.fillStyle='#FFF38B';x.fill();x.lineWidth=r*.12;x.strokeStyle='#f2c94c';x.stroke();x.restore()},
  flower:(x,r)=>{x.fillStyle='#FFB8D0';x.strokeStyle='#ff8fb8';x.lineWidth=r*.06;for(let i=0;i<5;i++){const a=i*2*Math.PI/5-Math.PI/2;x.beginPath();x.arc(Math.cos(a)*.5*r,Math.sin(a)*.5*r,.38*r,0,7);x.fill();x.stroke()}x.fillStyle='#FFF38B';dot(x,0,0,.32*r);face(x,.9*r,0)},
  bow:(x,r)=>{x.fillStyle='#FFB8D0';x.strokeStyle='#ff8fb8';x.lineWidth=r*.08;[-1,1].forEach(s=>{x.beginPath();x.moveTo(0,0);x.bezierCurveTo(s*.5*r,-.7*r,s*1.05*r,-.55*r,s*.95*r,0);x.bezierCurveTo(s*1.05*r,.55*r,s*.5*r,.7*r,0,0);x.closePath();x.fill();x.stroke()});x.fillStyle='#ff9fc0';x.beginPath();x.arc(0,0,.2*r,0,7);x.fill();x.stroke()},
  sparkle:(x,r)=>{x.beginPath();for(let i=0;i<8;i++){const a=-Math.PI/2+i*Math.PI/4,q=i%2?.22:1;x.lineTo(Math.cos(a)*r*q,Math.sin(a)*r*q)}x.closePath();x.fillStyle='#A2E1FF';x.strokeStyle='#ffffff';x.lineWidth=r*.1;x.stroke();x.fill()}
};
export const STICKERS=Object.keys(SD);
export function drawSticker(x,s,W,H){const r=s.size*W/2;x.save();x.translate(s.x*W,s.y*H);x.rotate(s.rot*Math.PI/180);x.globalAlpha=1;x.lineJoin='round';x.lineCap='round';SD[s.kind](x,r);x.restore()}

export function wmMetrics(x,S,W){
  if(S.mode==='png'&&S.png){const w=W*S.size/100*.8;return{w,h:w*S.png.naturalHeight/S.png.naturalWidth}}
  const fp=Math.max(8,W*S.size/100*.22);x.font='700 '+fp+'px '+S.font+',"Baloo 2",sans-serif';
  return{w:x.measureText(S.text||' ').width,h:fp*1.25,fp};
}
export function wmDraw1(x,S,m){
  if(S.mode==='png'&&S.png){x.drawImage(S.png,-m.w/2,-m.h/2,m.w,m.h);return}
  x.font='700 '+m.fp+'px '+S.font+',"Baloo 2",sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillStyle=S.color;x.fillText(S.text||'',0,0);
}
export function drawWM(x,item,S,W,H){
  if(S.mode==='png'&&!S.png)return;if(S.mode==='text'&&!S.text)return;
  x.save();x.globalAlpha=S.opacity/100;const m=wmMetrics(x,S,W),rot=S.rot*Math.PI/180;
  if(S.tile){
    const gap=S.gap/1000*W,sx=m.w+gap,sy=m.h+gap,d=Math.hypot(W,H),nx=Math.min(60,Math.ceil(d/sx)+1),ny=Math.min(60,Math.ceil(d/sy)+1);
    x.translate(W/2,H/2);x.rotate(rot);
    for(let j=-ny;j<=ny;j++)for(let i=-nx;i<=nx;i++){x.save();x.translate(i*sx+(j&1?sx/2:0),j*sy);wmDraw1(x,S,m);x.restore()}
  }else{x.translate(item.wmPos.x*W,item.wmPos.y*H);x.rotate(rot);wmDraw1(x,S,m)}
  x.restore();
}
/* paints one image (cropped, watermarked, stickered). o.full shows the whole source with a crop overlay */
export function paint(cv,item,S,maxW,o){
  o=o||{};const c=o.full?{x:0,y:0,w:1,h:1}:item.crop;
  const sw=c.w*item.w,sh=c.h*item.h,sc=maxW?Math.min(1,maxW/sw):1,W=Math.max(1,Math.round(sw*sc)),H=Math.max(1,Math.round(sh*sc));
  cv.width=W;cv.height=H;const x=cv.getContext('2d');
  x.drawImage(item.img,c.x*item.w,c.y*item.h,sw,sh,0,0,W,H);
  if(o.full){
    const r=o.rect;if(!r)return;const a=r.x*W,b=r.y*H,w=r.w*W,hh=r.h*H;
    x.fillStyle='rgba(30,20,80,.55)';x.fillRect(0,0,W,b);x.fillRect(0,b+hh,W,H-b-hh);x.fillRect(0,b,a,hh);x.fillRect(a+w,b,W-a-w,hh);
    x.setLineDash([10,7]);x.lineWidth=Math.max(2,W/300);x.strokeStyle='#fff';x.strokeRect(a,b,w,hh);x.setLineDash([]);return;
  }
  drawWM(x,item,S,W,H);item.stickers.forEach(s=>drawSticker(x,s,W,H));
  const sel=o.sel;if(!sel)return;
  x.save();x.setLineDash([8,6]);x.lineWidth=Math.max(2,W/400);x.strokeStyle='#ffffff';x.shadowColor='rgba(59,52,134,.9)';x.shadowBlur=4;
  if(sel.k==='s'){const s=item.stickers.find(t=>t.id===sel.id);if(s){const q=s.size*W;x.translate(s.x*W,s.y*H);x.rotate(s.rot*Math.PI/180);x.strokeRect(-q/2,-q/2,q,q)}}
  else if(sel.k==='w'&&!S.tile&&(S.mode==='text'?S.text:S.png)){const m=wmMetrics(x,S,W);x.translate(item.wmPos.x*W,item.wmPos.y*H);x.rotate(S.rot*Math.PI/180);x.strokeRect(-m.w/2-6,-m.h/2-4,m.w+12,m.h+8)}
  x.restore();
}
export function StickerPreview({kind}){
  const ref=useRef();
  useEffect(()=>{const c=ref.current,x=c.getContext('2d');x.clearRect(0,0,64,64);x.translate(32,32);x.lineJoin='round';SD[kind](x,24)},[kind]);
  return $.canvas({ref,width:64,height:64});
}
export function Thumb({item,S,tick}){
  const ref=useRef();
  useEffect(()=>{paint(ref.current,item,S,160,{})},[item,S,tick]);
  return $.canvas({ref});
}

export function Studio(){
  const A=useApp(),L=A.L;
  const [items,setItems]=useState([]),[act,setAct]=useState(null),[sel,setSel]=useState(null),[crop,setCrop]=useState(false),[rect,setRect]=useState(null);
  const [S,setS]=useState({mode:'text',text:'HOUSE OF SYION 🎀',color:'#ffffff',font:'Baloo 2',size:26,opacity:18,rot:-30,tile:true,gap:90,png:null,pngName:''});
  const [tick,setTick]=useState(0),[res,setRes]=useState(null),[over,setOver]=useState(false),[folder,setFolder]=useState(true);
  const cv=useRef(),box=useRef(),drag=useRef(null),fileIn=useRef(),pngIn=useRef();
  const item=items.find(i=>i.id===act)||null;
  const upd=(id,fn)=>setItems(p=>p.map(i=>i.id===id?fn(i):i));
  const set=(k,v)=>setS(p=>({...p,[k]:v}));
  useEffect(()=>{ensureFonts().then(()=>setTick(t=>t+1))},[]);
  useEffect(()=>{
    if(!item||!cv.current)return;
    const mw=Math.min(1200,(box.current?box.current.clientWidth:700)*Math.min(window.devicePixelRatio||1,1.5));
    if(crop)paint(cv.current,item,S,mw,{full:true,rect});else paint(cv.current,item,S,mw,{sel});
  },[item,S,sel,crop,rect,tick]);

  const addFiles=async fl=>{
    const files=Array.from(fl).filter(f=>f.type.startsWith('image/'));if(!files.length)return;
    const room=10-items.length;if(files.length>room)toast(L('Maksimal 10 gambar','Maximum 10 images'));
    const nw=[];
    for(const f of files.slice(0,Math.max(room,0))){
      try{const img=await loadImg(fileURL(f));nw.push({id:uid(),name:f.name,img,w:img.naturalWidth,h:img.naturalHeight,crop:{x:0,y:0,w:1,h:1},stickers:[],wmPos:{x:.5,y:.5}})}catch(e){toast(L('Gambar gagal dibaca','Could not read an image'))}
    }
    if(nw.length){setItems(p=>p.concat(nw));if(!act)setAct(nw[0].id)}
  };
  const loadPng=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;try{const img=await loadImg(fileURL(f));setS(p=>({...p,mode:'png',png:img,pngName:f.name}))}catch(x){toast(L('PNG gagal dibaca','Could not read the PNG'))}};
  const removeImg=id=>{setItems(p=>p.filter(i=>i.id!==id));if(act===id){const rest=items.filter(i=>i.id!==id);setAct(rest[0]?rest[0].id:null);setSel(null);setCrop(false)}};

  const pos=e=>{const r=cv.current.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width,y:(e.clientY-r.top)/r.height}};
  const hitWM=p=>{
    if(S.tile||(S.mode==='png'?!S.png:!S.text))return false;
    const x=cv.current.getContext('2d'),W=cv.current.width,H=cv.current.height,m=wmMetrics(x,S,W),a=-S.rot*Math.PI/180,dx=(p.x-item.wmPos.x)*W,dy=(p.y-item.wmPos.y)*H;
    const lx=dx*Math.cos(a)-dy*Math.sin(a),ly=dx*Math.sin(a)+dy*Math.cos(a);
    return Math.abs(lx)<m.w/2+10&&Math.abs(ly)<m.h/2+10;
  };
  const down=e=>{
    if(!item)return;const p=pos(e);try{cv.current.setPointerCapture(e.pointerId)}catch(x){}
    if(crop){drag.current={k:'crop',x0:p.x,y0:p.y};setRect({x:p.x,y:p.y,w:0,h:0});return}
    const W=cv.current.width,H=cv.current.height;
    for(let i=item.stickers.length-1;i>=0;i--){const s=item.stickers[i];if(Math.hypot((p.x-s.x)*W,(p.y-s.y)*H)<s.size*W/2*.9){setSel({k:'s',id:s.id});drag.current={k:'s',id:s.id,dx:p.x-s.x,dy:p.y-s.y};return}}
    if(hitWM(p)){setSel({k:'w'});drag.current={k:'w',dx:p.x-item.wmPos.x,dy:p.y-item.wmPos.y};return}
    setSel(null);
  };
  const move=e=>{
    const d=drag.current;if(!d||!item)return;const p=pos(e),cl=v=>Math.min(1,Math.max(0,v));
    if(d.k==='crop'){setRect({x:cl(Math.min(d.x0,p.x)),y:cl(Math.min(d.y0,p.y)),w:Math.min(Math.abs(p.x-d.x0),1),h:Math.min(Math.abs(p.y-d.y0),1)});return}
    if(d.k==='s')upd(item.id,i=>({...i,stickers:i.stickers.map(s=>s.id===d.id?{...s,x:cl(p.x-d.dx),y:cl(p.y-d.dy)}:s)}));
    if(d.k==='w')upd(item.id,i=>({...i,wmPos:{x:cl(p.x-d.dx),y:cl(p.y-d.dy)}}));
  };
  const up=()=>{drag.current=null};

  const cropTo=n=>{
    const o=item.crop,cv2=(px,py)=>({x:(o.x+px*o.w-n.x)/n.w,y:(o.y+py*o.h-n.y)/n.h});
    upd(item.id,i=>({...i,crop:{x:n.x,y:n.y,w:n.w,h:n.h},stickers:i.stickers.map(s=>({...s,...cv2(s.x,s.y),size:s.size*o.w/n.w})),wmPos:cv2(i.wmPos.x,i.wmPos.y)}));
  };
  const toggleCrop=()=>{if(!item)return;if(!crop){setRect({...item.crop});setSel(null)}setCrop(!crop)};
  const applyCrop=()=>{if(!rect||rect.w<.03||rect.h<.03){toast(L('Tarik area crop dulu ya','Drag a crop area first'));return}cropTo(rect);setCrop(false);setRect(null)};
  const resetCrop=()=>{cropTo({x:0,y:0,w:1,h:1});setCrop(false);setRect(null)};

  const addSticker=k=>{
    if(!item){toast(L('Tambah gambar dulu ya','Add an image first'));return}
    const s={id:uid(),kind:k,x:.5,y:.5,size:.18,rot:0};upd(item.id,i=>({...i,stickers:i.stickers.concat(s)}));setSel({k:'s',id:s.id});
  };
  const selSt=item&&sel&&sel.k==='s'?item.stickers.find(s=>s.id===sel.id):null;
  const updSt=patch=>upd(item.id,i=>({...i,stickers:i.stickers.map(s=>s.id===sel.id?{...s,...patch}:s)}));
  const delSt=()=>{upd(item.id,i=>({...i,stickers:i.stickers.filter(s=>s.id!==sel.id)}));setSel(null)};
  const applyAll=()=>{
    if(!item)return;
    setItems(p=>p.map(i=>i.id===item.id?i:{...i,stickers:item.stickers.map(s=>({...s,id:uid()})),wmPos:{...item.wmPos}}));
    toast(L('Watermark & stiker disalin ke semua gambar ✧','Watermark & stickers applied to all images ✧'));
  };
  const render=async it=>{
    await ensureFonts();const c=document.createElement('canvas');paint(c,it,S,null,{});
    const blob=await new Promise(r=>c.toBlob(r,'image/png'));
    return{name:(it.name.replace(/\.\w+$/,'')||'image')+'-syion-hd.png',url:URL.createObjectURL(blob),testi:true};
  };
  const dlOne=async()=>{if(!item)return;try{setRes([await render(item)])}catch(e){toast(L('Gagal membuat gambar HD','Could not render the HD image'))}};
  const dlAll=async()=>{try{const r=[];for(const it of items)r.push(await render(it));setRes(r)}catch(e){toast(L('Gagal membuat gambar HD','Could not render the HD images'))}};

  const stage=item
    ?$.div({ref:box,className:'canvas-box'},$.canvas({ref:cv,onPointerDown:down,onPointerMove:move,onPointerUp:up,onPointerCancel:up,'aria-label':L('Kanvas gambar','Image canvas')}))
    :$.div({className:'drop'+(over?' on':'')},
        $.div({style:{fontSize:'2.4rem'}},'🖼'),
        $.h3(L('Seret gambar ke sini','Drag images here')),
        $.p({className:'muted'},L('Sampai 10 screenshot chat. Kamu bisa tempel watermark dan stiker sensor.','Up to 10 chat screenshots. Add a watermark and censor stickers.')),
        $.button({className:'btn btn-star',onClick:()=>fileIn.current.click()},'＋ '+L('Pilih gambar','Choose images')));

  return $.div({className:'stack'},
    $.h2({className:'sec-title'},'Watermark Studio',$.small('✧ '+L('lindungi testimoni & sensor data pelanggan','protect reviews & censor customer data'))),
    $.div({className:'win',onDragOver:e=>{e.preventDefault();setOver(true)},onDragLeave:()=>setOver(false),onDrop:e=>{e.preventDefault();setOver(false);addFiles(e.dataTransfer.files)}},
      $.div({className:'win-bar'},$.i(),$.i(),$.span({style:{flex:1,textAlign:'center'}},'syion-studio.exe'),$.i(),$.i()),
      $.div({className:'win-menu'},
        $.input({ref:fileIn,type:'file',accept:'image/*',multiple:true,hidden:true,id:'studio-files',onChange:e=>{addFiles(e.target.files);e.target.value=''}}),
        $.button({className:'btn btn-ghost btn-sm',onClick:()=>fileIn.current.click(),disabled:items.length>=10},'＋ '+L('Gambar','Images')+' ('+items.length+'/10)'),
        $.button({className:'btn btn-ghost btn-sm','aria-pressed':crop,onClick:toggleCrop,disabled:!item},'✂ '+(crop?L('Selesai crop','Exit crop'):'Crop')),
        crop?$.button({className:'btn btn-pink btn-sm',onClick:applyCrop},L('Terapkan crop','Apply crop')):null,
        crop||(item&&(item.crop.w<1||item.crop.h<1))?$.button({className:'btn btn-ghost btn-sm',onClick:resetCrop},L('Reset crop','Reset crop')):null,
          $.div({className:'folder folder-inline'},
            $.button({className:'folder-tab','aria-expanded':folder,onClick:()=>setFolder(!folder)},'📁 '+L('Stiker','Stickers')+(folder?' ▾':' ▸')),
            folder?$.div({className:'folder-b'},
              $.div({className:'stk'},STICKERS.map(k=>$.button({key:k,'aria-label':'Add '+k+' sticker',title:k,onClick:()=>addSticker(k)},h(StickerPreview,{kind:k})))),
              selSt?$.div({className:'stack',style:{gap:8}},
                h(Field,{label:L('Ukuran stiker','Sticker size')},$.input({id:'st-size',type:'range',min:4,max:70,value:Math.round(selSt.size*100),onChange:e=>updSt({size:e.target.value/100})})),
                h(Field,{label:L('Putar stiker','Sticker rotation')},$.input({id:'st-rot',type:'range',min:-180,max:180,value:selSt.rot,onChange:e=>updSt({rot:+e.target.value})})),
                $.button({className:'btn btn-danger btn-sm',onClick:delSt},'🗑 '+L('Hapus stiker','Delete sticker')))
              :$.p({className:'muted',style:{fontSize:'.85rem'}},L('Tap stiker untuk menaruhnya, lalu seret di gambar.','Tap a sticker to place it, then drag it on the image.'))):null),
        $.button({className:'btn btn-pink btn-sm',onClick:applyAll,disabled:items.length<2},'✨ '+L('Terapkan ke Semua','Apply to All')),
        $.span({className:'sp'}),
        $.button({className:'btn btn-star',onClick:dlOne,disabled:!item,style:{borderRadius:999,padding:'9px 22px'}},'⬇ Download HD'),
        items.length>1?$.button({className:'btn btn-ghost btn-sm',onClick:dlAll},L('Semua','All')+' ('+items.length+')'):null),
      $.div({className:'win-body'},
        $.div({className:'stage'},
          stage,
          items.length?$.div({className:'thumbs'},items.map(it=>$.div({key:it.id,className:'thumb','aria-current':it.id===act,onClick:()=>{setAct(it.id);setSel(null);setCrop(false)},role:'button',tabIndex:0,onKeyDown:e=>{if(e.key==='Enter')setAct(it.id)},'aria-label':it.name},
            h(Thumb,{item:it,S,tick}),
            $.button({className:'btn btn-danger btn-ico x',style:{background:'var(--solid)',padding:'0 6px'},'aria-label':'Remove image',onClick:e=>{e.stopPropagation();removeImg(it.id)}},'✕')))):null,
          crop?$.p({className:'muted',style:{marginTop:8}},L('Mode crop: tarik di gambar untuk memilih area, lalu “Terapkan crop”.','Crop mode: drag on the image to pick an area, then “Apply crop”.')):null),
        $.div({className:'ctl'},
          $.div({className:'radios'},[['text',L('Teks','Text')],['png','PNG']].map(m=>$.button({key:m[0],'aria-pressed':S.mode===m[0],onClick:()=>set('mode',m[0])},m[1]))),
          S.mode==='text'
            ?$.div({className:'stack',style:{gap:10}},
                h(Field,{label:L('Teks watermark','Watermark text')},$.input({id:'wm-text',type:'text',value:S.text,onChange:e=>set('text',e.target.value)})),
                $.div({className:'form-grid',style:{gridTemplateColumns:'1fr 1fr'}},
                  h(Field,{label:L('Font','Font')},$.select({id:'wm-font',value:S.font,onChange:e=>set('font',e.target.value)},['Baloo 2','Chewy','Sniglet','Quicksand'].map(f=>$.option({key:f,value:f},f)))),
                  h(Field,{label:L('Warna','Color')},$.input({id:'wm-color',type:'color',value:S.color,onChange:e=>set('color',e.target.value)}))))
            :$.div({className:'stack',style:{gap:8}},
                $.input({ref:pngIn,type:'file',accept:'image/png',hidden:true,id:'wm-png',onChange:loadPng}),
                $.button({className:'btn btn-ghost btn-sm',onClick:()=>pngIn.current.click()},'⬆ '+L('Unggah PNG watermark','Upload watermark PNG')),
                $.span({className:'muted'},S.pngName||L('Belum ada PNG','No PNG yet'))),
          h(Field,{label:L('Ukuran / Zoom','Size / Zoom')+' · '+S.size+'%'},$.input({id:'wm-size',type:'range',min:6,max:100,value:S.size,onChange:e=>set('size',+e.target.value)})),
          h(Field,{label:L('Transparansi','Opacity')+' · '+S.opacity+'%'},$.input({id:'wm-op',type:'range',min:5,max:100,value:S.opacity,onChange:e=>set('opacity',+e.target.value)})),
          $.p({className:'muted',style:{fontSize:'.8rem',marginTop:-6}},L('Saran 15 sampai 20% supaya tetap terbaca.','15 to 20% keeps the picture readable.')),
          h(Field,{label:L('Sudut rotasi (°)','Rotation angle (°)')},$.input({id:'wm-rot',type:'number',min:-180,max:180,step:1,value:S.rot,onChange:e=>set('rot',Math.max(-180,Math.min(180,+e.target.value||0)))})),
          h(Field,{plain:true,label:'Tiling / Grid'},h(Switch,{id:'wm-tile',on:S.tile,set:v=>set('tile',v),label:S.tile?L('Ulang di seluruh gambar','Repeat across image'):L('Satu watermark (bisa digeser)','Single (drag to move)')})),
          S.tile?h(Field,{label:L('Jarak antar watermark','Spacing')},$.input({id:'wm-gap',type:'range',min:0,max:300,value:S.gap,onChange:e=>set('gap',+e.target.value)})):null))),
    res?h(ImageModal,{results:res,onClose:()=>setRes(null),title:'Download HD'}):null);
}
