import { createServerFn } from '@tanstack/react-start';
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';
import { STORE_KEYS, type RawStore } from './store-model';

// Public storefront content comes from the anon-readable `kv` table. Nothing private is read here.
export const readStore = createServerFn({ method: 'GET' }).handler(async (): Promise<RawStore> => {
  const key = process.env['SUPABASE_PUBLISHABLE_KEY'];
  const url = process.env['SUPABASE_URL'];
  if (!key || !url) throw new Error('Katalog belum terhubung');
  const client = createClient<Database>(url, key, {
    auth: { persistSession: false },
    global: {
      fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        if (key.startsWith('sb_') && headers.get('Authorization') === `Bearer ${key}`) headers.delete('Authorization');
        headers.set('apikey', key);
        return fetch(input, { ...init, headers });
      },
    },
  });
  const { data, error } = await client.from('kv').select('key,value').in('key', [...STORE_KEYS]);
  if (error) throw error;
  const raw: RawStore = {};
  for (const row of data ?? []) raw[row.key] = row.value;
  return raw;
});
